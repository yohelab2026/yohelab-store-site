<?php
/**
 * Archive template.
 *
 * @package Bunsirube
 */

get_header();
?>
<main id="content">
  <section class="bunsirube-hero">
    <div class="bunsirube-wrap">
      <div class="bunsirube-hero-card">
        <span class="bunsirube-eyebrow">Archive</span>
        <h1 class="bunsirube-title"><?php the_archive_title(); ?></h1>
        <p class="bunsirube-lead"><?php the_archive_description(); ?></p>
      </div>
    </div>
  </section>
  <div class="bunsirube-wrap"><?php bunsirube_breadcrumb_html(); ?></div>
  <div class="bunsirube-wrap bunsirube-main">
    <div class="bunsirube-content">
      <?php while (have_posts()) : the_post(); ?>
        <article <?php post_class('bunsirube-article'); ?>>
          <h2 class="bunsirube-post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <div class="bunsirube-entry"><?php the_excerpt(); ?></div>
        </article>
      <?php endwhile; ?>
      <?php the_posts_pagination(); ?>
    </div>
    <?php get_sidebar(); ?>
  </div>
</main>
<?php get_footer(); ?>
