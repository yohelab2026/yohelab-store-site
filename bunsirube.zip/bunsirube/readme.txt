=== 文標 ===
Contributors: yohelab
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 8.0
Stable tag: 0.3.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

比較記事、レビュー記事、FAQ記事を迷わず書き始めるための軽量WordPressテーマです。

== Description ==

文標は、見た目だけではなく「何を書けばいいか」まで用意するテーマです。
記事の型、FAQ、著者情報、比較表カード、ブログカード、CTA、導線確認、構造化データの出力をまとめています。

Core features:

* Article, WebSite, Person, BreadcrumbList, and FAQPage JSON-LD output.
* FAQ, summary, comparison cards, blog cards, citation, table of contents, CTA, and author shortcodes.
* Lightweight CTA, comparison button, blog card, and ad-link click tracking when internal analytics is enabled.
* Seven article patterns: basic posts, comparison posts, reviews, FAQ posts, rankings, product introductions, and case introductions.
* Lightweight article planning panel on post and page edit screens.
* llms.txt endpoint.
* llms.txt is an optional guide for some AI crawlers. It does not guarantee visibility in Google AI Overviews or other AI features.
* Optional internal analytics. Disabled by default.
* Optional meta tags, OGP, JSON-LD, FAQPage JSON-LD, and llms.txt output toggles.
* Safe .htaccess editor with automatic backups and restore.
* GA4 and Google Search Console settings.
* Main color and text color controls in the theme settings screen.

== Installation ==

1. Upload the bunsirube theme folder or ZIP file from Appearance > Themes > Add New.
2. Activate 文標.
3. Open Appearance > 文標 and set colors, output options, analytics, and license fields.

== Frequently Asked Questions ==

= Is this a plugin replacement? =

No. It reduces overlap for small content sites, but payment, forms, advanced security, backup, and full cache/CDN features should remain outside the theme.

= Does it require Google Analytics? =

No. GA4 is optional. Internal analytics is also optional and disabled by default.

= What does internal analytics save? =

It saves post view counts and referrer hosts inside WordPress. It does not track individuals.

= What happens if I switch themes after using shortcodes? =

文標 shortcodes such as [bunsirube_faq] may remain visible in the post body after switching themes.

= Can I customize it with a child theme? =

Yes. Use the Bunsirube child theme ZIP for CSS and small function customizations. Keep the parent theme installed so updates continue to work.

= How do blog cards work? =

Paste a URL on its own line to show it as a blog card. Internal links use local post data. External links fetch basic title and description data briefly and cache it.

= Can I use an SEO plugin together with this theme? =

Yes. You can disable meta tags, OGP, JSON-LD, FAQPage JSON-LD, and llms.txt from Appearance > 文標 to avoid duplicate output.

== Changelog ==

= 0.3.2 =
* Expands theme.json color palette to 12 colors including teal, blue, amber, red, muted, and border variants.
* Adds two gradient presets (brand-gradient and brand-gradient-soft) for block editor use.
* Adds xs and xx-large font size presets.
* Adds block gap, padding, margin, border, radius, and line-height settings to theme.json.
* Adds styles defaults for headings (h1–h3), links, and link hover in theme.json.
* Added versioned ZIP bunsirube-0.3.2.zip.

= 0.3.1 =
* Adds a warning that admin-screen restore cannot be used if a broken .htaccess blocks wp-admin.
* Adds text downloads for the current .htaccess and stored backups.
* Added versioned ZIP bunsirube-0.3.1.zip.

= 0.3.0 =
* Adds a safe .htaccess editor under Appearance > .htaccess.
* Automatically backs up the current .htaccess before saving.
* Allows restoring recent .htaccess backups from the admin screen.
* Adds .htaccess editability to the accident-prevention checklist.
* Blocks editing when DISALLOW_FILE_EDIT is enabled or the file target is unsafe.
* Added versioned ZIP bunsirube-0.3.0.zip.

= 0.2.9 =
* Adds an accident-prevention checklist in Appearance > Bunsirube.
* Adds an on/off setting for automatic blog cards.
* Warns about SEO output duplication, double caching, legacy shortcode remnants, and parent-theme customization risk.

= 0.2.8 =
* Uses Bunsirube naming for public handles and editor plugin IDs.
* Removes legacy shortcode aliases. Use bunsirube_* shortcodes.

= 0.2.7 =
* Fixes parent stylesheet loading for child theme usage.
* Adds support notes for the Bunsirube child theme package.

= 0.2.6 =
* Adds automatic blog cards for standalone URL lines.
* Adds the [bunsirube_blog_card] shortcode.
* Adds a blog card insertion button to the editor article planning panel.
* Adds blog card click tracking to internal route checks.
* Added versioned ZIP bunsirube-0.2.6.zip.

= 0.2.5 =
* Clarifies the install ZIP names.
* Adds CTA, ad link, and comparison card shortcodes to the theme-change caution.
* Clarifies that llms.txt is optional and does not guarantee Google AI feature visibility.
* Clarifies the 30-day initial support scope.
* Added versioned ZIP bunsirube-0.2.5.zip.

= 0.2.4 =
* Adds a safe fallback for environments without mb_substr().
* Adds an AI-search-aware short-answer checklist item, making the editor checklist 12 items.
* Clarifies that AI search support is based on visible answers, evidence, FAQ, and sources rather than special tricks.
* Added versioned ZIP bunsirube-0.2.4.zip.

= 0.2.3 =
* Accepts true, yes, and on values for comparison card sponsored and target_blank attributes.
* Adds clearer copy for route-click stats when internal analytics is still off.
* Added versioned ZIP bunsirube-0.2.3.zip.

= 0.2.2 =
* Avoids registering a standard WordPress update response when no licensed package URL is available.
* Warns about remaining placeholder text in addition to example.com sample URLs.
* Shows route click totals as post title / type / label in the dashboard widget.
* Adds sponsored and target_blank options to comparison card links.
* Added versioned ZIP bunsirube-0.2.2.zip.

= 0.2.1 =
* Aligned all eleven article checklist fields with PHP post-meta registration.
* Shows per-post CTA, comparison, and ad-link click counts in the editor sidebar.
* Adds a warning when example.com sample URLs remain in post content.
* Accepts click tracking only for published posts.
* Notes that route click numbers are reference values for article improvement.
* Uses a valid fixed ZIP timestamp for packaged files.
* Added versioned ZIP bunsirube-0.2.1.zip.

= 0.2.0 =
* Added comparison card shortcodes [bunsirube_compare_grid] and [bunsirube_compare_item].
* Added lightweight click tracking for CTA, comparison buttons, and ad links when internal analytics is enabled.
* Added title, source, comparison, and mobile checks to the article planning checklist.
* Added a comparison card insertion button to the editor article planning panel.
* Reworked design presets into Plain, Soft, and Sharp.
* Added versioned ZIP bunsirube-0.2.0.zip.

= 0.1.7 =
* Updated screenshot.png to show version 0.1.7.
* Added sample CTA blocks to comparison, review, product introduction, and case introduction patterns.
* Improved table-of-contents ID detection for single-quoted id attributes.
* Added a one-click button to disable theme SEO outputs when SEO plugins are active.
* Added an update-info refresh button in the theme settings screen.
* Added versioned ZIP bunsirube-0.1.7.zip.

= 0.1.6 =
* Added a CTA insertion button to the editor article planning panel.
* Aligned the seven article type labels across README, readme.txt, and admin screens.
* Improved FAQPage JSON-LD extraction to support single-quoted shortcode attributes.
* Reduced license status cache to five minutes.
* Removed the site URL from the update-check User-Agent.
* Added versioned ZIP bunsirube-0.1.6.zip.

= 0.1.5 =
* Added [bunsirube_cta] CTA shortcode.
* Added bunsirube_* shortcode names.
* Only adds table-of-contents heading IDs when a TOC shortcode exists.
* Keeps existing heading IDs instead of overwriting them.
* Hides footer credit by default and adds a setting to enable it.
* Shows internal analytics widgets only when internal analytics is enabled.
* Aligns editor article types to seven patterns.
* Adds a warning when common SEO plugins are active.
* Adds versioned ZIP naming.

= 0.1.4 =
* Unified visible product name to 文標.
* Changed Text Domain to bunsirube.
* Reworked settings page for buyers.
* Disabled internal analytics by default.
* Disabled transient cache while internal analytics is enabled.
* Added output toggles for meta tags, OGP, JSON-LD, FAQPage JSON-LD, and llms.txt.
* Changed license check to POST.
* Changed heading insertion to native block insertion.
* Excluded .github from packaged ZIP.

= 0.1.3 =
* Added WordPress standard theme supports and styles.
* Moved widget registration to widgets_init.
* Replaced file-based cache with transient-based cache.
* Added paginated post/page links and tag output.
