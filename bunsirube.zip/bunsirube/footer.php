<?php
/**
 * Footer.
 *
 * @package Bunsirube
 */
?>
<footer class="bunsirube-footer">
  <div class="bunsirube-wrap">
    <div>&copy; <?php echo esc_html(date_i18n('Y')); ?> <?php bloginfo('name'); ?><?php if (bunsirube_get_option('show_footer_credit', '0') === '1') : ?> / Powered by 文標<?php endif; ?></div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
