<?php
/**
 * Custom search form.
 *
 * @package Bunsirube
 */
?>
<form role="search" method="get" class="bunsirube-search-form" action="<?php echo esc_url(home_url('/')); ?>">
  <label class="screen-reader-text" for="bunsirube-search-field"><?php esc_html_e('Search for:', 'bunsirube'); ?></label>
  <input type="search" id="bunsirube-search-field" class="bunsirube-search-input" placeholder="<?php esc_attr_e('キーワードを入力', 'bunsirube'); ?>" value="<?php echo esc_attr(get_search_query()); ?>" name="s" />
  <button type="submit" class="bunsirube-btn"><?php esc_html_e('検索', 'bunsirube'); ?></button>
</form>
