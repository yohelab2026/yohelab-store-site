<?php
/**
 * Main template.
 *
 * @package Bunsirube
 */

get_header();
?>
<main id="content">
  <section class="bunsirube-hero">
    <div class="bunsirube-wrap">
      <div class="bunsirube-hero-card">
        <span class="bunsirube-eyebrow">文標</span>
        <h1 class="bunsirube-title"><?php bloginfo('name'); ?></h1>
        <p class="bunsirube-lead"><?php bloginfo('description'); ?></p>
      </div>
    </div>
  </section>
  <div class="bunsirube-wrap bunsirube-main">
    <div class="bunsirube-content">
      <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
          <article <?php post_class('bunsirube-article'); ?>>
            <h2 class="bunsirube-post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <div class="bunsirube-meta">
              <span><?php echo esc_html(get_the_date()); ?></span>
              <span><?php the_author_posts_link(); ?></span>
            </div>
            <div class="bunsirube-entry"><?php the_excerpt(); ?></div>
          </article>
        <?php endwhile; ?>
        <?php the_posts_pagination(); ?>
      <?php else : ?>
        <article class="bunsirube-article"><p>記事がまだありません。</p></article>
      <?php endif; ?>
    </div>
    <?php get_sidebar(); ?>
  </div>
</main>
<?php get_footer(); ?>
