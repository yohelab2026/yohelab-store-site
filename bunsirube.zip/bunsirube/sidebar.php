<?php
/**
 * Sidebar.
 *
 * @package Bunsirube
 */
?>
<aside class="bunsirube-sidebar">
  <?php if (is_active_sidebar('sidebar-1')) : ?>
    <?php dynamic_sidebar('sidebar-1'); ?>
  <?php endif; ?>
  <section class="bunsirube-widget">
    <h2>サイト内検索</h2>
    <?php get_search_form(); ?>
  </section>
  <?php if (bunsirube_get_option('internal_analytics', '0') === '1') : ?>
    <?php
    $popular = get_posts(array(
        'posts_per_page' => 5,
        'meta_key'       => '_bunsirube_views',
        'meta_value'     => 0,
        'meta_compare'   => '>',
        'orderby'        => 'meta_value_num',
        'order'          => 'DESC',
    ));
    ?>
    <?php if ($popular) : ?>
      <section class="bunsirube-widget">
        <h2>人気記事</h2>
        <ol>
          <?php foreach ($popular as $post) : setup_postdata($post); ?>
            <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
          <?php endforeach; wp_reset_postdata(); ?>
        </ol>
      </section>
    <?php endif; ?>
  <?php endif; ?>
</aside>
