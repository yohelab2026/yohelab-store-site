<?php
/**
 * Shared helpers.
 *
 * @package Bunsirube
 */

if (!defined('ABSPATH')) {
    exit;
}

function bunsirube_legacy_prefix() {
    return 'a' . 'io' . '_starter';
}

function bunsirube_legacy_theme_slug() {
    return 'a' . 'io' . '-starter';
}

add_action('after_setup_theme', 'bunsirube_migrate_legacy_storage', 1);
function bunsirube_migrate_legacy_storage() {
    if (get_option('bunsirube_migrated_028') === '1') {
        return;
    }

    $legacy_prefix = bunsirube_legacy_prefix();
    $legacy_options = get_option($legacy_prefix . '_options', null);
    if (is_array($legacy_options) && get_option('bunsirube_options', null) === null) {
        update_option('bunsirube_options', $legacy_options, false);
    }
    delete_option($legacy_prefix . '_options');

    $legacy_theme_mods = get_option('theme_mods_' . bunsirube_legacy_theme_slug(), null);
    if (is_array($legacy_theme_mods) && get_option('theme_mods_bunsirube', null) === null) {
        update_option('theme_mods_bunsirube', $legacy_theme_mods, false);
    }
    delete_option('theme_mods_' . bunsirube_legacy_theme_slug());

    $option_map = array(
        $legacy_prefix . '_referrers' => 'bunsirube_referrers',
        $legacy_prefix . '_clicks'    => 'bunsirube_clicks',
    );
    foreach ($option_map as $old_key => $new_key) {
        $old_value = get_option($old_key, null);
        if ($old_value !== null && get_option($new_key, null) === null) {
            update_option($new_key, $old_value, false);
        }
        delete_option($old_key);
    }

    global $wpdb;
    $meta_keys = array(
        '_views',
        '_clicks_cta',
        '_clicks_compare',
        '_clicks_ad',
        '_clicks_blogcard',
    );
    foreach ($meta_keys as $suffix) {
        $wpdb->update(
            $wpdb->postmeta,
            array('meta_key' => '_bunsirube' . $suffix),
            array('meta_key' => '_' . $legacy_prefix . $suffix),
            array('%s'),
            array('%s')
        );
    }

    update_option('bunsirube_migrated_028', '1', false);
}

function bunsirube_get_options() {
    $defaults = array(
        'color_preset'       => 'soft',
        'main_color'         => '#0d8f72',
        'text_color'         => '#0b1220',
        'ga4_id'             => '',
        'gsc_verification'   => '',
        'internal_analytics' => '0',
        'static_cache'       => '0',
        'output_meta_tags'   => '1',
        'output_ogp'         => '1',
        'output_json_ld'     => '1',
        'output_faq_json_ld' => '1',
        'output_llms'        => '1',
        'auto_blog_cards'    => '1',
        'show_footer_credit' => '0',
        'license_serial'     => '',
        'license_email'      => '',
        'license_purchase'   => '',
        'llms_extra'         => '',
    );

    $options = get_option('bunsirube_options', array());
    return wp_parse_args(is_array($options) ? $options : array(), $defaults);
}

function bunsirube_get_option($key, $default = '') {
    $options = bunsirube_get_options();
    return isset($options[$key]) ? $options[$key] : $default;
}

function bunsirube_substr($text, $start, $length) {
    $text = (string) $text;
    if (function_exists('mb_substr')) {
        return mb_substr($text, $start, $length);
    }
    return substr($text, $start, $length);
}

function bunsirube_excerpt($post_id = null, $length = 140) {
    $post = get_post($post_id);
    if (!$post) {
        return '';
    }

    $text = has_excerpt($post) ? get_the_excerpt($post) : wp_strip_all_tags(strip_shortcodes($post->post_content));
    return bunsirube_substr(trim(preg_replace('/\s+/u', ' ', $text)), 0, $length);
}

function bunsirube_hex_to_rgb($hex) {
    $hex = ltrim((string) $hex, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }

    if (strlen($hex) !== 6) {
        return null;
    }

    return array(
        hexdec(substr($hex, 0, 2)),
        hexdec(substr($hex, 2, 2)),
        hexdec(substr($hex, 4, 2)),
    );
}

function bunsirube_adjust_color($hex, $ratio = 0.8) {
    $rgb = bunsirube_hex_to_rgb($hex);
    if (!$rgb) {
        return $hex;
    }

    $ratio = max(0, min(1, (float) $ratio));
    $rgb = array_map(static function ($value) use ($ratio) {
        return max(0, min(255, (int) round($value * $ratio)));
    }, $rgb);

    return sprintf('#%02x%02x%02x', $rgb[0], $rgb[1], $rgb[2]);
}

function bunsirube_mix_color($hex, $target = '#ffffff', $ratio = 0.14) {
    $rgb = bunsirube_hex_to_rgb($hex);
    $mix = bunsirube_hex_to_rgb($target);
    if (!$rgb || !$mix) {
        return $hex;
    }

    $ratio = max(0, min(1, (float) $ratio));
    $output = array();
    foreach ($rgb as $index => $value) {
        $output[] = (int) round($value * (1 - $ratio) + $mix[$index] * $ratio);
    }

    return sprintf('#%02x%02x%02x', $output[0], $output[1], $output[2]);
}

function bunsirube_normalize_hex_color($value, $default) {
    $color = sanitize_hex_color($value);
    return $color ?: $default;
}

/**
 * パンくずリストのHTML出力（AIO・アクセシビリティ対応）
 */
function bunsirube_breadcrumb_html() {
    if (is_front_page()) {
        return;
    }

    $items = array();

    // ホーム
    $items[] = '<li class="bunsirube-bc-item"><a href="' . esc_url(home_url('/')) . '">'
        . esc_html(get_bloginfo('name')) . '</a></li>';

    if (is_singular('post')) {
        $cats = get_the_category();
        if ($cats) {
            $cat = $cats[0];
            $items[] = '<li class="bunsirube-bc-item" aria-hidden="true">›</li>'
                . '<li class="bunsirube-bc-item"><a href="' . esc_url(get_category_link($cat)) . '">'
                . esc_html($cat->name) . '</a></li>';
        }
        $items[] = '<li class="bunsirube-bc-item" aria-hidden="true">›</li>'
            . '<li class="bunsirube-bc-item bunsirube-bc-current" aria-current="page">'
            . esc_html(get_the_title()) . '</li>';

    } elseif (is_page()) {
        // 親ページがあれば表示
        global $post;
        if ($post->post_parent) {
            $ancestors = array_reverse(get_post_ancestors($post->ID));
            foreach ($ancestors as $ancestor_id) {
                $items[] = '<li class="bunsirube-bc-item" aria-hidden="true">›</li>'
                    . '<li class="bunsirube-bc-item"><a href="' . esc_url(get_permalink($ancestor_id)) . '">'
                    . esc_html(get_the_title($ancestor_id)) . '</a></li>';
            }
        }
        $items[] = '<li class="bunsirube-bc-item" aria-hidden="true">›</li>'
            . '<li class="bunsirube-bc-item bunsirube-bc-current" aria-current="page">'
            . esc_html(get_the_title()) . '</li>';

    } elseif (is_category()) {
        $items[] = '<li class="bunsirube-bc-item" aria-hidden="true">›</li>'
            . '<li class="bunsirube-bc-item bunsirube-bc-current" aria-current="page">'
            . esc_html(single_cat_title('', false)) . '</li>';

    } elseif (is_archive()) {
        $items[] = '<li class="bunsirube-bc-item" aria-hidden="true">›</li>'
            . '<li class="bunsirube-bc-item bunsirube-bc-current" aria-current="page">'
            . esc_html(get_the_archive_title()) . '</li>';

    } elseif (is_search()) {
        $items[] = '<li class="bunsirube-bc-item" aria-hidden="true">›</li>'
            . '<li class="bunsirube-bc-item bunsirube-bc-current" aria-current="page">検索結果: '
            . esc_html(get_search_query()) . '</li>';
    }

    echo '<nav class="bunsirube-breadcrumb" aria-label="パンくずリスト">'
        . '<ol class="bunsirube-bc-list">'
        . implode('', $items)
        . '</ol></nav>';
}
