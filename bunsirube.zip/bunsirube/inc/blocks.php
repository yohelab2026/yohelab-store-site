<?php
/**
 * Content blocks as shortcodes and patterns.
 *
 * @package Bunsirube
 */

if (!defined('ABSPATH')) {
    exit;
}

add_shortcode('bunsirube_faq', 'bunsirube_shortcode_faq');
function bunsirube_shortcode_faq($atts, $content = '') {
    $atts = shortcode_atts(array('question' => ''), $atts, 'bunsirube_faq');
    if (!$atts['question']) {
        return '';
    }

    $allowed = array(
        'a'      => array('href' => true, 'title' => true, 'target' => true, 'rel' => true),
        'br'     => array(),
        'em'     => array(),
        'strong' => array(),
        'p'      => array(),
        'ul'     => array(),
        'ol'     => array(),
        'li'     => array(),
        'code'   => array(),
        'span'   => array('class' => true),
    );

    return '<details class="bunsirube-faq"><summary>' . esc_html($atts['question']) . '</summary><div class="bunsirube-faq-answer">' . wpautop(wp_kses(do_shortcode($content), $allowed)) . '</div></details>';
}

add_shortcode('bunsirube_summary', 'bunsirube_shortcode_summary');
function bunsirube_shortcode_summary($atts, $content = '') {
    $atts = shortcode_atts(array('title' => 'この記事のポイント'), $atts, 'bunsirube_summary');
    return '<div class="bunsirube-summary"><strong>' . esc_html($atts['title']) . '</strong>' . wpautop(wp_kses_post(do_shortcode($content))) . '</div>';
}

add_shortcode('bunsirube_author', 'bunsirube_shortcode_author');
function bunsirube_shortcode_author($atts) {
    $atts = shortcode_atts(array(
        'twitter' => '',
        'x'       => '',
        'website' => '',
        'expertise' => '',
    ), $atts, 'bunsirube_author');

    global $post;
    $author_id = $post ? (int) $post->post_author : 0;
    if (!$author_id) {
        return '';
    }

    $name        = get_the_author_meta('display_name', $author_id);
    $description = get_the_author_meta('description', $author_id);
    $author_url  = get_author_posts_url($author_id);

    // 専門分野（shortcode 属性 または カスタムフィールド）
    $expertise   = $atts['expertise'] ?: get_the_author_meta('aio_expertise', $author_id);

    // SNS リンク（shortcode 属性 → カスタムフィールド の順で取得）
    $twitter = $atts['twitter'] ?: $atts['x'] ?: get_the_author_meta('twitter', $author_id);
    $website = $atts['website'] ?: get_the_author_meta('user_url', $author_id);

    $social = '';
    if ($twitter) {
        $handle  = ltrim($twitter, '@');
        $social .= '<a class="bunsirube-author-sns" href="https://twitter.com/' . esc_attr($handle) . '" target="_blank" rel="noopener noreferrer">𝕏 @' . esc_html($handle) . '</a>';
    }
    if ($website) {
        $social .= '<a class="bunsirube-author-sns" href="' . esc_url($website) . '" target="_blank" rel="noopener noreferrer">🌐 ウェブサイト</a>';
    }

    $expertise_html = $expertise ? '<span class="bunsirube-author-expertise">' . esc_html($expertise) . '</span>' : '';

    return '<div class="bunsirube-author-box">' .
        get_avatar($author_id, 144, '', esc_attr($name), array('class' => 'bunsirube-author-avatar')) .
        '<div class="bunsirube-author-info">' .
            '<strong class="bunsirube-author-name">' . esc_html($name) . '</strong>' .
            $expertise_html .
            '<p class="bunsirube-author-bio">' . esc_html($description) . '</p>' .
            ($social ? '<div class="bunsirube-author-links">' . $social . '</div>' : '') .
        '</div>' .
        '</div>';
}

add_shortcode('bunsirube_compare', 'bunsirube_shortcode_compare');
function bunsirube_shortcode_compare($atts, $content = '') {
    return '<div class="bunsirube-compare">' . wp_kses_post(do_shortcode($content)) . '</div>';
}

add_shortcode('bunsirube_compare_grid', 'bunsirube_shortcode_compare_grid');
function bunsirube_shortcode_compare_grid($atts, $content = '') {
    return '<div class="bunsirube-compare-grid">' . do_shortcode($content) . '</div>';
}

function bunsirube_bool_attr($value) {
    return in_array(strtolower((string) $value), array('1', 'true', 'yes', 'on'), true);
}

add_shortcode('bunsirube_compare_item', 'bunsirube_shortcode_compare_item');
function bunsirube_shortcode_compare_item($atts) {
    $atts = shortcode_atts(array(
        'name'    => '商品名',
        'price'   => '',
        'feature' => '',
        'fit'     => '',
        'caution' => '',
        'label'   => '',
        'button'  => '詳しく見る',
        'url'     => '',
        'sponsored' => '0',
        'target_blank' => '0',
    ), $atts, 'bunsirube_compare_item');

    $rows = array(
        '特徴' => $atts['feature'],
        '向いている人' => $atts['fit'],
        '注意点' => $atts['caution'],
    );

    $html = '<article class="bunsirube-compare-card">';
    if ($atts['label']) {
        $html .= '<span class="bunsirube-compare-label">' . esc_html($atts['label']) . '</span>';
    }
    $html .= '<h3>' . esc_html($atts['name']) . '</h3>';
    if ($atts['price']) {
        $html .= '<p class="bunsirube-compare-price">' . esc_html($atts['price']) . '</p>';
    }
    $html .= '<dl class="bunsirube-compare-list">';
    foreach ($rows as $label => $value) {
        if ($value) {
            $html .= '<div><dt>' . esc_html($label) . '</dt><dd>' . esc_html($value) . '</dd></div>';
        }
    }
    $html .= '</dl>';
    if ($atts['url']) {
        $target_blank = bunsirube_bool_attr($atts['target_blank']);
        $sponsored = bunsirube_bool_attr($atts['sponsored']);
        $target = $target_blank ? ' target="_blank"' : '';
        $rel = $sponsored ? ' rel="nofollow sponsored noopener noreferrer"' : ($target ? ' rel="noopener noreferrer"' : '');
        $html .= '<a class="bunsirube-btn bunsirube-track-click" data-bunsirube-click-type="compare" data-bunsirube-click-label="' . esc_attr($atts['name']) . '" href="' . esc_url($atts['url']) . '"' . $target . $rel . '>' . esc_html($atts['button']) . '</a>';
    }
    return $html . '</article>';
}

add_shortcode('bunsirube_blog_card', 'bunsirube_shortcode_blog_card');
function bunsirube_shortcode_blog_card($atts) {
    $atts = shortcode_atts(array(
        'url'          => '',
        'title'        => '',
        'description'  => '',
        'image'        => '',
        'label'        => '',
        'target_blank' => 'auto',
    ), $atts, 'bunsirube_blog_card');

    return bunsirube_render_blog_card($atts['url'], $atts);
}

add_filter('the_content', 'bunsirube_auto_blog_cards', 7);
function bunsirube_auto_blog_cards($content) {
    if (bunsirube_get_option('auto_blog_cards', '1') !== '1' || is_admin() || is_feed() || is_embed()) {
        return $content;
    }

    $content = preg_replace_callback('/<!--\s+wp:paragraph\s+-->\s*<p>\s*(https?:\/\/[^\s<]+)\s*<\/p>\s*<!--\s+\/wp:paragraph\s+-->/i', function ($matches) {
        $url = rtrim($matches[1], " \t\n\r\0\x0B.,");
        return bunsirube_blog_card_shortcode_markup($url) ?: $matches[0];
    }, $content);

    $content = preg_replace_callback('/<p>\s*(https?:\/\/[^\s<]+)\s*<\/p>/i', function ($matches) {
        $url = rtrim($matches[1], " \t\n\r\0\x0B.,");
        return bunsirube_blog_card_shortcode_markup($url) ?: $matches[0];
    }, $content);

    $content = preg_replace_callback('/<p>\s*<a\s+[^>]*href=([\'"])(https?:\/\/[^\'"]+)\1[^>]*>(.*?)<\/a>\s*<\/p>/is', function ($matches) {
        $url = html_entity_decode($matches[2], ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8');
        $text = trim(html_entity_decode(wp_strip_all_tags($matches[3]), ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8'));
        if ($text !== $url) {
            return $matches[0];
        }
        return bunsirube_blog_card_shortcode_markup($url) ?: $matches[0];
    }, $content);

    $content = preg_replace_callback('/(^|[\r\n])\s*(https?:\/\/[^\s<]+)\s*(?=$|[\r\n])/i', function ($matches) {
        $url = rtrim($matches[2], " \t\n\r\0\x0B.,");
        $shortcode = bunsirube_blog_card_shortcode_markup($url);
        return $shortcode ? $matches[1] . $shortcode : $matches[0];
    }, $content);

    return $content;
}

function bunsirube_blog_card_shortcode_markup($url) {
    $url = bunsirube_normalize_blog_card_url($url);
    if (!$url) {
        return '';
    }
    return '[bunsirube_blog_card url="' . esc_url_raw($url) . '"]';
}

function bunsirube_render_blog_card($url, $overrides = array()) {
    $url = bunsirube_normalize_blog_card_url($url);
    if (!$url) {
        return '';
    }

    $is_internal = bunsirube_is_internal_url($url);
    $data = (!$is_internal && !empty($overrides['title']))
        ? array(
            'title'       => bunsirube_blog_card_host($url),
            'description' => '',
            'image'       => '',
            'label'       => bunsirube_blog_card_host($url),
        )
        : bunsirube_blog_card_data($url);
    foreach (array('title', 'description', 'label') as $key) {
        if (!empty($overrides[$key])) {
            $data[$key] = bunsirube_clean_blog_card_text($overrides[$key], $key === 'description' ? 160 : 90);
        }
    }
    if (!empty($overrides['image'])) {
        $data['image'] = bunsirube_resolve_blog_card_url($overrides['image'], $url);
    }

    $target_blank = isset($overrides['target_blank']) && $overrides['target_blank'] !== 'auto'
        ? bunsirube_bool_attr($overrides['target_blank'])
        : !$is_internal;
    $target = $target_blank ? ' target="_blank"' : '';
    $rel = $target_blank ? ' rel="noopener noreferrer"' : '';
    $title = $data['title'] ?: bunsirube_blog_card_host($url);
    $label = $data['label'] ?: ($is_internal ? get_bloginfo('name') : bunsirube_blog_card_host($url));

    $image = '';
    if (!empty($data['image'])) {
        $image = '<span class="bunsirube-blog-card-image"><img src="' . esc_url($data['image']) . '" alt="" loading="lazy" decoding="async"></span>';
    } else {
        $image = '<span class="bunsirube-blog-card-fallback" aria-hidden="true">Link</span>';
    }

    return '<a class="bunsirube-blog-card bunsirube-track-click" data-bunsirube-click-type="blogcard" data-bunsirube-click-label="' . esc_attr($title) . '" href="' . esc_url($url) . '"' . $target . $rel . '>' .
        $image .
        '<span class="bunsirube-blog-card-body">' .
        '<span class="bunsirube-blog-card-label">' . esc_html($label) . '</span>' .
        '<strong class="bunsirube-blog-card-title">' . esc_html($title) . '</strong>' .
        (!empty($data['description']) ? '<span class="bunsirube-blog-card-description">' . esc_html($data['description']) . '</span>' : '') .
        '<span class="bunsirube-blog-card-url">' . esc_html(bunsirube_blog_card_display_url($url)) . '</span>' .
        '</span>' .
        '</a>';
}

function bunsirube_blog_card_data($url) {
    $post_id = url_to_postid($url);
    if ($post_id) {
        return array(
            'title'       => get_the_title($post_id),
            'description' => bunsirube_excerpt($post_id, 140),
            'image'       => has_post_thumbnail($post_id) ? (string) get_the_post_thumbnail_url($post_id, 'medium_large') : '',
            'label'       => get_bloginfo('name'),
        );
    }

    if (!bunsirube_is_internal_url($url)) {
        return bunsirube_remote_blog_card_data($url);
    }

    return array(
        'title'       => bunsirube_blog_card_host($url),
        'description' => '',
        'image'       => '',
        'label'       => get_bloginfo('name'),
    );
}

function bunsirube_remote_blog_card_data($url) {
    $fallback = array(
        'title'       => bunsirube_blog_card_host($url),
        'description' => '',
        'image'       => '',
        'label'       => bunsirube_blog_card_host($url),
    );

    if (!function_exists('wp_safe_remote_get') || (function_exists('wp_http_validate_url') && !wp_http_validate_url($url))) {
        return $fallback;
    }

    $cache_key = 'bunsirube_blog_card_' . md5($url);
    $cached = get_transient($cache_key);
    if (is_array($cached)) {
        return wp_parse_args($cached, $fallback);
    }

    $response = wp_safe_remote_get($url, array(
        'timeout'             => 1.8,
        'redirection'         => 3,
        'limit_response_size' => 180000,
        'headers'             => array(
            'Accept' => 'text/html,application/xhtml+xml',
        ),
    ));

    if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) >= 400) {
        set_transient($cache_key, $fallback, HOUR_IN_SECONDS);
        return $fallback;
    }

    $body = (string) wp_remote_retrieve_body($response);
    $data = bunsirube_extract_blog_card_meta($body, $url);
    $data = wp_parse_args($data, $fallback);
    set_transient($cache_key, $data, WEEK_IN_SECONDS);
    return $data;
}

function bunsirube_extract_blog_card_meta($html, $base_url) {
    $title = bunsirube_find_meta_content($html, array('og:title', 'twitter:title'));
    if (!$title && preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $match)) {
        $title = $match[1];
    }

    $description = bunsirube_find_meta_content($html, array('og:description', 'twitter:description', 'description'));
    $image = bunsirube_find_meta_content($html, array('og:image', 'twitter:image'));

    return array(
        'title'       => bunsirube_clean_blog_card_text($title, 90),
        'description' => bunsirube_clean_blog_card_text($description, 150),
        'image'       => $image ? bunsirube_resolve_blog_card_url($image, $base_url) : '',
        'label'       => bunsirube_blog_card_host($base_url),
    );
}

function bunsirube_find_meta_content($html, $names) {
    if (!preg_match_all('/<meta\s+([^>]+)>/i', $html, $matches)) {
        return '';
    }

    $names = array_map('strtolower', $names);
    foreach ($matches[1] as $raw_attrs) {
        $attrs = wp_kses_hair($raw_attrs, wp_allowed_protocols());
        $name = '';
        if (!empty($attrs['property']['value'])) {
            $name = strtolower((string) $attrs['property']['value']);
        } elseif (!empty($attrs['name']['value'])) {
            $name = strtolower((string) $attrs['name']['value']);
        }
        if ($name && in_array($name, $names, true) && !empty($attrs['content']['value'])) {
            return (string) $attrs['content']['value'];
        }
    }
    return '';
}

function bunsirube_normalize_blog_card_url($url) {
    $url = trim(html_entity_decode(wp_strip_all_tags((string) $url), ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8'));
    if (!preg_match('/^https?:\/\//i', $url)) {
        return '';
    }
    $parts = wp_parse_url($url);
    if (empty($parts['scheme']) || empty($parts['host']) || !in_array(strtolower($parts['scheme']), array('http', 'https'), true)) {
        return '';
    }
    return esc_url_raw($url);
}

function bunsirube_is_internal_url($url) {
    $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
    $home_host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
    return $host && $home_host && preg_replace('/^www\./', '', $host) === preg_replace('/^www\./', '', $home_host);
}

function bunsirube_blog_card_host($url) {
    $host = (string) wp_parse_url($url, PHP_URL_HOST);
    return preg_replace('/^www\./i', '', $host) ?: $url;
}

function bunsirube_blog_card_display_url($url) {
    $host = bunsirube_blog_card_host($url);
    $path = (string) wp_parse_url($url, PHP_URL_PATH);
    $path = $path && $path !== '/' ? untrailingslashit($path) : '';
    return bunsirube_substr($host . $path, 0, 76);
}

function bunsirube_clean_blog_card_text($text, $length = 120) {
    $text = html_entity_decode((string) $text, ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8');
    $text = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($text)));
    return bunsirube_substr($text, 0, $length);
}

function bunsirube_resolve_blog_card_url($url, $base_url) {
    $url = trim(html_entity_decode((string) $url, ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8'));
    if (preg_match('/^https?:\/\//i', $url)) {
        return esc_url_raw($url);
    }
    if (strpos($url, '//') === 0) {
        $scheme = wp_parse_url($base_url, PHP_URL_SCHEME) ?: 'https';
        return esc_url_raw($scheme . ':' . $url);
    }

    $base = wp_parse_url($base_url);
    if (empty($base['scheme']) || empty($base['host'])) {
        return '';
    }

    if (strpos($url, '/') === 0) {
        return esc_url_raw($base['scheme'] . '://' . $base['host'] . $url);
    }

    $path = isset($base['path']) ? preg_replace('#/[^/]*$#', '/', $base['path']) : '/';
    return esc_url_raw($base['scheme'] . '://' . $base['host'] . $path . $url);
}

// 引用・出典ブロック
add_shortcode('bunsirube_cite', 'bunsirube_shortcode_cite');
function bunsirube_shortcode_cite($atts, $content = '') {
    $atts = shortcode_atts(array('source' => '', 'url' => ''), $atts, 'bunsirube_cite');
    $source_html = '';
    if ($atts['url']) {
        $source_html = '<cite class="bunsirube-cite-source"><a href="' . esc_url($atts['url']) . '" target="_blank" rel="noopener noreferrer">' . esc_html($atts['source'] ?: $atts['url']) . '</a></cite>';
    } elseif ($atts['source']) {
        $source_html = '<cite class="bunsirube-cite-source">' . esc_html($atts['source']) . '</cite>';
    }
    return '<blockquote class="bunsirube-blockquote">' . wpautop(wp_kses_post(do_shortcode($content))) . $source_html . '</blockquote>';
}

// 目次ブロック（h2/h3 自動生成）
add_shortcode('bunsirube_toc', 'bunsirube_shortcode_toc');
function bunsirube_shortcode_toc($atts, $content = '') {
    $atts = shortcode_atts(array('title' => '目次'), $atts, 'bunsirube_toc');

    global $post;
    if (!$post) {
        return '';
    }

    $items_data = bunsirube_collect_toc_items($post->post_content);
    if (!$items_data) {
        return '';
    }

    $items = '';
    foreach ($items_data as $item) {
        $indent = $item['level'] === 3 ? ' bunsirube-toc-sub' : '';
        $items .= '<li class="bunsirube-toc-item' . $indent . '"><a href="#' . esc_attr($item['id']) . '">' . esc_html($item['text']) . '</a></li>';
    }

    if (!$items) {
        return '';
    }

    return '<nav class="bunsirube-toc" aria-label="目次"><strong class="bunsirube-toc-title">' . esc_html($atts['title']) . '</strong><ol class="bunsirube-toc-list">' . wp_kses_post($items) . '</ol></nav>';
}

add_filter('the_content', 'bunsirube_add_heading_ids');
function bunsirube_add_heading_ids($content) {
    if (!has_shortcode($content, 'bunsirube_toc')) {
        return $content;
    }

    $counter = 1;
    $content = preg_replace_callback('/<h([23])([^>]*)>(.*?)<\/h[23]>/is', function ($m) use (&$counter) {
        $level   = $m[1];
        $attrs   = $m[2];
        $text    = $m[3];
        if (preg_match('/\sid=([\'"])(.*?)\1/i', $attrs, $id_match)) {
            $counter++;
            return '<h' . $level . $attrs . '>' . $text . '</h' . $level . '>';
        }
        $id = 'bunsirube-toc-' . $counter++;
        return '<h' . $level . $attrs . ' id="' . esc_attr($id) . '">' . $text . '</h' . $level . '>';
    }, $content);
    return $content;
}

function bunsirube_collect_toc_items($content) {
    if (!preg_match_all('/<h([23])([^>]*)>(.*?)<\/h[23]>/is', $content, $matches, PREG_SET_ORDER)) {
        return array();
    }

    $items = array();
    $counter = 1;
    foreach ($matches as $m) {
        $id = '';
        if (preg_match('/\sid=([\'"])(.*?)\1/i', $m[2], $id_match)) {
            $id = $id_match[2];
        } else {
            $id = 'bunsirube-toc-' . $counter;
        }
        $items[] = array(
            'level' => (int) $m[1],
            'id'    => sanitize_html_class($id),
            'text'  => wp_strip_all_tags($m[3]),
        );
        $counter++;
    }
    return $items;
}

add_shortcode('bunsirube_cta', 'bunsirube_shortcode_cta');
function bunsirube_shortcode_cta($atts, $content = '') {
    $atts = shortcode_atts(array(
        'title'  => '次にすること',
        'text'   => '',
        'button' => '詳しく見る',
        'url'    => '',
        'type'   => 'default',
    ), $atts, 'bunsirube_cta');

    $text = $atts['text'] ?: $content;
    $button = '';
    if ($atts['url']) {
        $button = '<a class="bunsirube-btn bunsirube-track-click" data-bunsirube-click-type="cta" data-bunsirube-click-label="' . esc_attr($atts['title']) . '" href="' . esc_url($atts['url']) . '">' . esc_html($atts['button']) . '</a>';
    }

    $type = sanitize_html_class($atts['type'] ?: 'default');
    return '<div class="bunsirube-cta bunsirube-cta-type-' . esc_attr($type) . '">' .
        '<strong class="bunsirube-cta-title">' . esc_html($atts['title']) . '</strong>' .
        ($text ? '<p class="bunsirube-cta-text">' . esc_html(wp_strip_all_tags($text)) . '</p>' : '') .
        $button .
        '</div>';
}

add_shortcode('bunsirube_ad_link', 'bunsirube_shortcode_ad_link');
function bunsirube_shortcode_ad_link($atts) {
    $atts = shortcode_atts(array(
        'text'  => '公式サイトを見る',
        'url'   => '',
        'label' => '',
    ), $atts, 'bunsirube_ad_link');

    if (!$atts['url']) {
        return '';
    }

    $label = $atts['label'] ?: $atts['text'];
    return '<a class="bunsirube-btn bunsirube-track-click" data-bunsirube-click-type="ad" data-bunsirube-click-label="' . esc_attr($label) . '" href="' . esc_url($atts['url']) . '" target="_blank" rel="nofollow sponsored noopener noreferrer">' . esc_html($atts['text']) . '</a>';
}

add_action('init', 'bunsirube_register_patterns');
function bunsirube_register_patterns() {
    if (!function_exists('register_block_pattern')) {
        return;
    }

    if (function_exists('register_block_pattern_category')) {
        register_block_pattern_category('bunsirube-templates', array(
            'label' => __('記事テンプレート', 'bunsirube'),
        ));
    }

    $patterns = array(
        'bunsirube-article-template' => array(
            'title'       => __('基本記事テンプレート', 'bunsirube'),
            'description' => __('結論、根拠、注意点、FAQ、要点まとめを最初から入れた基本型。', 'bunsirube'),
            'content'     => '<!-- wp:shortcode -->[bunsirube_summary title="この記事の結論"]結論を3行で書きます。誰に向いているか、何が分かるか、先に答えを書きます。[/bunsirube_summary]<!-- /wp:shortcode --><!-- wp:heading --><h2>結論</h2><!-- /wp:heading --><!-- wp:paragraph --><p>読者が最初に知りたい答えを書きます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>根拠</h2><!-- /wp:heading --><!-- wp:paragraph --><p>なぜそう言えるのか、データ、体験、公式情報などを整理します。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>注意点</h2><!-- /wp:heading --><!-- wp:paragraph --><p>向いていないケースや、誤解されやすいポイントを書きます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>よくある質問</h2><!-- /wp:heading --><!-- wp:shortcode -->[bunsirube_faq question="よくある質問を入れる"]回答を短く具体的に書きます。[/bunsirube_faq]<!-- /wp:shortcode -->',
        ),
        'comparison-template' => array(
            'title'       => __('比較記事テンプレート', 'bunsirube'),
            'description' => __('複数商品やサービスの比較記事に使う型。', 'bunsirube'),
            'content'     => '<!-- wp:shortcode -->[bunsirube_summary title="比較の結論"]迷ったら最初に選ぶべきもの、条件別のおすすめ、選ばない方がいいケースを書きます。[/bunsirube_summary]<!-- /wp:shortcode --><!-- wp:heading --><h2>比較するもの</h2><!-- /wp:heading --><!-- wp:paragraph --><p>比較対象と、この記事で見る基準を先に書きます。</p><!-- /wp:paragraph --><!-- wp:shortcode -->[bunsirube_compare_grid][bunsirube_compare_item name="Aサービス" price="価格を入力" feature="特徴を入力" fit="向いている人を入力" caution="注意点を入力" label="おすすめ" button="詳しく見る" url="https://example.com"][bunsirube_compare_item name="Bサービス" price="価格を入力" feature="特徴を入力" fit="向いている人を入力" caution="注意点を入力" button="詳しく見る" url="https://example.com"][/bunsirube_compare_grid]<!-- /wp:shortcode --><!-- wp:heading --><h2>選び方</h2><!-- /wp:heading --><!-- wp:paragraph --><p>価格、目的、使いやすさ、サポートなどの判断基準を書きます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>FAQ</h2><!-- /wp:heading --><!-- wp:shortcode -->[bunsirube_faq question="どれを選べばいいですか？"]条件別に短く答えます。[/bunsirube_faq]<!-- /wp:shortcode -->',
        ),
        'review-template' => array(
            'title'       => __('レビュー記事テンプレート', 'bunsirube'),
            'description' => __('体験、メリット、デメリット、向いている人を整理するレビュー型。', 'bunsirube'),
            'content'     => '<!-- wp:shortcode -->[bunsirube_summary title="レビューの結論"]実際に使った結論、良かった点、注意点を先にまとめます。[/bunsirube_summary]<!-- /wp:shortcode --><!-- wp:heading --><h2>使って分かったこと</h2><!-- /wp:heading --><!-- wp:paragraph --><p>体験ベースで、何が良かったかを書きます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>メリット</h2><!-- /wp:heading --><!-- wp:list {"className":"is-style-bunsirube-checklist"} --><ul class="is-style-bunsirube-checklist"><li>良かった点を入れる</li><li>便利だった場面を入れる</li><li>他と違う点を入れる</li></ul><!-- /wp:list --><!-- wp:heading --><h2>デメリット・注意点</h2><!-- /wp:heading --><!-- wp:paragraph --><p>合わない人、気になる点、事前に知るべきことを書きます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>向いている人</h2><!-- /wp:heading --><!-- wp:paragraph --><p>どんな人なら満足しやすいかを書きます。</p><!-- /wp:paragraph -->',
        ),
        'case-introduction-template' => array(
            'title'       => __('案件紹介記事テンプレート', 'bunsirube'),
            'description' => __('案件、サービス、募集内容を分かりやすく紹介する型。', 'bunsirube'),
            'content'     => '<!-- wp:shortcode -->[bunsirube_summary title="この案件の要点"]誰向けか、何をする案件か、応募前に見るべき点をまとめます。[/bunsirube_summary]<!-- /wp:shortcode --><!-- wp:heading --><h2>案件の概要</h2><!-- /wp:heading --><!-- wp:paragraph --><p>案件名、内容、対象者、報酬や条件を書きます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>向いている人</h2><!-- /wp:heading --><!-- wp:list {"className":"is-style-bunsirube-checklist"} --><ul class="is-style-bunsirube-checklist"><li>向いている条件を入れる</li><li>必要なスキルを入れる</li><li>応募前に確認することを入れる</li></ul><!-- /wp:list --><!-- wp:heading --><h2>応募前の注意点</h2><!-- /wp:heading --><!-- wp:paragraph --><p>確認すべき条件やリスクを書きます。</p><!-- /wp:paragraph --><!-- wp:shortcode -->[bunsirube_faq question="初心者でも応募できますか？"]条件に分けて回答します。[/bunsirube_faq]<!-- /wp:shortcode -->',
        ),
        'ai-faq-template' => array(
            'title'       => __('FAQ記事テンプレート', 'bunsirube'),
            'description' => __('質問と回答を中心に、読み手が迷わない形へ整理する型。', 'bunsirube'),
            'content'     => '<!-- wp:shortcode -->[bunsirube_summary title="先に答え"]この記事で扱う質問への答えを短くまとめます。[/bunsirube_summary]<!-- /wp:shortcode --><!-- wp:heading --><h2>基本の答え</h2><!-- /wp:heading --><!-- wp:paragraph --><p>検索ユーザーが最初に知りたい答えを書きます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>よくある質問</h2><!-- /wp:heading --><!-- wp:shortcode -->[bunsirube_faq question="質問1"]回答1を具体的に書きます。[/bunsirube_faq]<!-- /wp:shortcode --><!-- wp:shortcode -->[bunsirube_faq question="質問2"]回答2を具体的に書きます。[/bunsirube_faq]<!-- /wp:shortcode --><!-- wp:shortcode -->[bunsirube_faq question="質問3"]回答3を具体的に書きます。[/bunsirube_faq]<!-- /wp:shortcode --><!-- wp:heading --><h2>補足と注意点</h2><!-- /wp:heading --><!-- wp:paragraph --><p>例外、注意点、古くなりやすい情報を書きます。</p><!-- /wp:paragraph -->',
        ),
        'ranking-template' => array(
            'title'       => __('ランキング記事テンプレート', 'bunsirube'),
            'description' => __('ランキングの根拠と選び方を明確にする型。', 'bunsirube'),
            'content'     => '<!-- wp:shortcode -->[bunsirube_summary title="ランキングの結論"]1位、2位、3位と、選んだ理由を短くまとめます。[/bunsirube_summary]<!-- /wp:shortcode --><!-- wp:heading --><h2>ランキングの基準</h2><!-- /wp:heading --><!-- wp:paragraph --><p>価格、使いやすさ、機能、信頼性など、評価基準を明記します。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>おすすめランキング</h2><!-- /wp:heading --><!-- wp:list {"ordered":true} --><ol><li><strong>1位：名称</strong><br>理由と向いている人を書きます。</li><li><strong>2位：名称</strong><br>理由と向いている人を書きます。</li><li><strong>3位：名称</strong><br>理由と向いている人を書きます。</li></ol><!-- /wp:list --><!-- wp:heading --><h2>選ぶときの注意点</h2><!-- /wp:heading --><!-- wp:paragraph --><p>ランキングだけで決めない方がいい条件を書きます。</p><!-- /wp:paragraph -->',
        ),
        'product-introduction-template' => array(
            'title'       => __('商品紹介記事テンプレート', 'bunsirube'),
            'description' => __('商品説明、Q&A、注意点、購入前チェックを整理する型。', 'bunsirube'),
            'content'     => '<!-- wp:shortcode -->[bunsirube_summary title="商品の要点"]何の商品か、誰に向いているか、購入前の注意点をまとめます。[/bunsirube_summary]<!-- /wp:shortcode --><!-- wp:heading --><h2>商品の特徴</h2><!-- /wp:heading --><!-- wp:paragraph --><p>特徴、強み、使える場面を書きます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>購入前に見るポイント</h2><!-- /wp:heading --><!-- wp:list {"className":"is-style-bunsirube-checklist"} --><ul class="is-style-bunsirube-checklist"><li>価格と内容が合っているか</li><li>自分の用途に合うか</li><li>注意点を理解しているか</li></ul><!-- /wp:list --><!-- wp:heading --><h2>よくある質問</h2><!-- /wp:heading --><!-- wp:shortcode -->[bunsirube_faq question="どんな人に向いていますか？"]向いている人を具体的に書きます。[/bunsirube_faq]<!-- /wp:shortcode --><!-- wp:shortcode -->[bunsirube_cite source="参考リンク" url="https://example.com"]参考にした情報や公式情報を書きます。[/bunsirube_cite]<!-- /wp:shortcode -->',
        ),
        'cta-box' => array(
            'title'       => __('CTAボックス', 'bunsirube'),
            'description' => __('記事の最後に、購入・問い合わせ・無料体験への行動を置く型。', 'bunsirube'),
            'content'     => '<!-- wp:shortcode -->[bunsirube_cta title="次にすること" text="ここに、読者に進んでほしい行動を短く書きます。" button="詳しく見る" url="https://example.com"]<!-- /wp:shortcode -->',
        ),
    );

    $default_cta = '<!-- wp:shortcode -->[bunsirube_cta title="迷ったら次に見ること" text="この記事の内容をもとに、次のページで詳しく確認できます。" button="詳しく見る" url="https://example.com"]<!-- /wp:shortcode -->';
    foreach (array('comparison-template', 'review-template', 'product-introduction-template', 'case-introduction-template') as $cta_pattern_slug) {
        if (isset($patterns[$cta_pattern_slug])) {
            $patterns[$cta_pattern_slug]['content'] .= $default_cta;
        }
    }

    foreach ($patterns as $slug => $pattern) {
        register_block_pattern('bunsirube/' . $slug, array(
            'title'       => $pattern['title'],
            'description' => $pattern['description'],
            'categories'  => array('bunsirube-templates', 'text'),
            'content'     => $pattern['content'],
        ));
    }
}
