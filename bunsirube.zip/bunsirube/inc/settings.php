<?php
/**
 * Theme settings page.
 *
 * @package Bunsirube
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', 'bunsirube_settings_menu');
function bunsirube_settings_menu() {
    add_theme_page(
        __('文標 設定', 'bunsirube'),
        __('文標', 'bunsirube'),
        'manage_options',
        'bunsirube',
        'bunsirube_settings_page'
    );
}

add_action('admin_init', 'bunsirube_register_settings');
function bunsirube_register_settings() {
    register_setting('bunsirube_options_group', 'bunsirube_options', array(
        'sanitize_callback' => 'bunsirube_sanitize_options',
    ));
}

function bunsirube_sanitize_options($input) {
    $input = is_array($input) ? $input : array();
    return array(
        'color_preset'       => in_array($input['color_preset'] ?? 'soft', array('plain', 'soft', 'sharp', 'green', 'light', 'dark'), true) ? $input['color_preset'] : 'soft',
        'main_color'         => bunsirube_normalize_hex_color($input['main_color'] ?? '#0d8f72', '#0d8f72'),
        'text_color'         => bunsirube_normalize_hex_color($input['text_color'] ?? '#0b1220', '#0b1220'),
        'ga4_id'             => sanitize_text_field($input['ga4_id'] ?? ''),
        'gsc_verification'   => sanitize_text_field($input['gsc_verification'] ?? ''),
        'internal_analytics' => !empty($input['internal_analytics']) ? '1' : '0',
        'static_cache'       => (!empty($input['static_cache']) && empty($input['internal_analytics'])) ? '1' : '0',
        'output_meta_tags'   => !empty($input['output_meta_tags']) ? '1' : '0',
        'output_ogp'         => !empty($input['output_ogp']) ? '1' : '0',
        'output_json_ld'     => !empty($input['output_json_ld']) ? '1' : '0',
        'output_faq_json_ld' => !empty($input['output_faq_json_ld']) ? '1' : '0',
        'output_llms'        => !empty($input['output_llms']) ? '1' : '0',
        'auto_blog_cards'    => !empty($input['auto_blog_cards']) ? '1' : '0',
        'show_footer_credit' => !empty($input['show_footer_credit']) ? '1' : '0',
        'license_serial'     => sanitize_text_field($input['license_serial'] ?? ''),
        'license_email'      => sanitize_email($input['license_email'] ?? ''),
        'license_purchase'   => sanitize_text_field($input['license_purchase'] ?? ''),
        'llms_extra'         => sanitize_textarea_field($input['llms_extra'] ?? ''),
    );
}

function bunsirube_license_status() {
    $options = bunsirube_get_options();
    if (empty($options['license_serial']) || empty($options['license_email']) || empty($options['license_purchase'])) {
        return array('active' => false, 'label' => '未認証', 'message' => '購入後メールのシリアル、メールアドレス、購入IDを入力してください。');
    }

    $cached = get_transient('bunsirube_license_status');
    if (is_array($cached)) {
        return $cached;
    }

    $response = wp_remote_post('https://yohelab.com/api/theme-license', array(
        'timeout' => 10,
        'headers' => array('Accept' => 'application/json'),
        'body' => array(
            'serial'   => $options['license_serial'],
            'email'    => $options['license_email'],
            'purchase' => $options['license_purchase'],
        ),
    ));

    if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) {
        return array('active' => false, 'label' => '確認失敗', 'message' => '通信できませんでした。時間を置いて再確認してください。');
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    $status = !empty($data['active'])
        ? array('active' => true, 'label' => '認証済み', 'message' => '更新通知とサポート対象として確認できました。', 'download_token' => sanitize_text_field($data['downloadToken'] ?? ''))
        : array('active' => false, 'label' => '未認証', 'message' => 'シリアル、メールアドレス、購入IDを確認してください。');

    set_transient('bunsirube_license_status', $status, 5 * MINUTE_IN_SECONDS);
    return $status;
}

function bunsirube_disable_theme_seo_outputs() {
    if (
        empty($_POST['bunsirube_disable_theme_seo']) ||
        !current_user_can('manage_options') ||
        !check_admin_referer('bunsirube_disable_theme_seo')
    ) {
        return;
    }

    $options = bunsirube_get_options();
    $options['output_meta_tags'] = '0';
    $options['output_ogp'] = '0';
    $options['output_json_ld'] = '0';
    $options['output_faq_json_ld'] = '0';
    update_option('bunsirube_options', $options);

    wp_safe_redirect(add_query_arg('bunsirube-seo-disabled', '1', admin_url('themes.php?page=bunsirube')));
    exit;
}
add_action('admin_init', 'bunsirube_disable_theme_seo_outputs');

function bunsirube_refresh_update_cache() {
    if (
        empty($_GET['bunsirube-refresh-update']) ||
        !current_user_can('manage_options') ||
        !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'bunsirube_refresh_update')
    ) {
        return;
    }

    delete_transient('bunsirube_update_data');
    delete_transient('update_themes');
    wp_safe_redirect(add_query_arg('bunsirube-update-refreshed', '1', admin_url('themes.php?page=bunsirube')));
    exit;
}
add_action('admin_init', 'bunsirube_refresh_update_cache');

function bunsirube_settings_page() {
    if (!function_exists('submit_button')) {
        require_once ABSPATH . 'wp-admin/includes/template.php';
    }

    $options = bunsirube_get_options();
    if (isset($_GET['settings-updated'])) {
        delete_transient('bunsirube_license_status');
    }
    $license = bunsirube_license_status();
    $seo_plugins = bunsirube_active_seo_plugins();
    $cache_plugins = bunsirube_active_cache_plugins();
    $safety_checks = bunsirube_safety_checks($options, $seo_plugins, $cache_plugins);
    $cards = array(
        array('title' => '色を決める', 'body' => 'メインカラーと文字色を決めます。最初は初期値のままでも使えます。'),
        array('title' => '記事タイプを選ぶ', 'body' => '投稿画面の「記事設計」で、基本記事、比較記事、レビュー記事、FAQ記事、ランキング記事、商品紹介記事、案件紹介記事から選びます。'),
        array('title' => '必要な出力だけON', 'body' => 'SEOプラグインを使っている場合は、メタタグ、OGP、JSON-LDをOFFにできます。'),
        array('title' => '.htaccessは慎重に', 'body' => '必要な場合だけ「外観 > .htaccess」から編集します。保存前の内容は自動バックアップします。'),
        array('title' => 'サポートを確認', 'body' => 'シリアルを入れると、更新確認と購入者サポートの対象確認に使えます。'),
    );
    ?>
    <div class="wrap">
      <h1>文標 設定</h1>
      <p>基本記事、比較記事、レビュー記事、FAQ記事、ランキング記事、商品紹介記事、案件紹介記事を迷わず書き始めるための設定画面です。まずは色と記事タイプだけ決めれば使い始められます。</p>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;max-width:980px;margin:16px 0 24px;">
        <?php foreach ($cards as $card) : ?>
          <div style="background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:16px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;">
              <strong><?php echo esc_html($card['title']); ?></strong>
            </div>
            <p style="margin:.6em 0 0;color:#646970;"><?php echo esc_html($card['body']); ?></p>
          </div>
        <?php endforeach; ?>
      </div>

      <h2>かんたん初期設定</h2>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;max-width:980px;margin:16px 0 24px;">
        <div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;">
          <strong>1. 色を決める</strong>
          <p style="margin:.5em 0 0;color:#646970;">メインカラーと文字色だけ変更。細かい装飾設定は増やしていません。</p>
        </div>
        <div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;">
          <strong>2. 記事タイプを選ぶ</strong>
          <p style="margin:.5em 0 0;color:#646970;">投稿画面の「記事設計」で、7種類の記事型から選びます。</p>
        </div>
        <div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;">
          <strong>3. FAQ・目次・著者ブロックを使う</strong>
          <p style="margin:.5em 0 0;color:#646970;">必要な記事部品をショートコードで入れます。テーマ変更時の注意はREADMEに書いています。</p>
        </div>
        <div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;">
          <strong>4. 必要なら外部ツールを入れる</strong>
          <p style="margin:.5em 0 0;color:#646970;">GA4、Search Console、バックアップ、フォームなどはサイトに合わせて選びます。</p>
        </div>
      </div>

      <h2>購入者認証</h2>
      <div style="max-width:980px;background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:16px;margin:16px 0 24px;">
        <p style="margin-top:0;"><strong>状態: <span style="color:<?php echo $license['active'] ? '#0d8f72' : '#b45309'; ?>"><?php echo esc_html($license['label']); ?></span></strong></p>
        <p style="color:#646970;"><?php echo esc_html($license['message']); ?></p>
        <p style="color:#646970;">テーマは認証なしでも表示できます。シリアル情報は購入者確認、更新確認、サポート対象確認のためによへラボのサーバーへ送信します。</p>
      </div>

      <?php if ($seo_plugins) : ?>
        <div class="notice notice-warning" style="max-width:980px;">
          <p><strong>SEOプラグインが有効です。</strong> <?php echo esc_html(implode('、', $seo_plugins)); ?> が見つかりました。重複を避けるため、文標のメタタグ / OGP / JSON-LD出力をOFFにすることをおすすめします。</p>
          <form method="post" style="margin:0 0 12px;">
            <?php wp_nonce_field('bunsirube_disable_theme_seo'); ?>
            <button type="submit" class="button button-secondary" name="bunsirube_disable_theme_seo" value="1">文標側のSEO出力をまとめてOFFにする</button>
          </form>
        </div>
      <?php endif; ?>
      <?php if (isset($_GET['bunsirube-seo-disabled'])) : ?>
        <div class="notice notice-success is-dismissible" style="max-width:980px;"><p>文標側のメタタグ / OGP / JSON-LD / FAQPage JSON-LD をOFFにしました。</p></div>
      <?php endif; ?>
      <?php if (isset($_GET['bunsirube-update-refreshed'])) : ?>
        <div class="notice notice-success is-dismissible" style="max-width:980px;"><p>更新情報を再取得しました。</p></div>
      <?php endif; ?>
      <?php if ($cache_plugins && $options['static_cache'] === '1') : ?>
        <div class="notice notice-warning" style="max-width:980px;">
          <p><strong>キャッシュ系プラグインが有効です。</strong> <?php echo esc_html(implode('、', $cache_plugins)); ?> が見つかりました。二重キャッシュは表示ズレの原因になりやすいため、文標の簡易キャッシュはOFFにすることをおすすめします。</p>
        </div>
      <?php endif; ?>

      <h2>事故防止チェック</h2>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;max-width:980px;margin:16px 0 24px;">
        <?php foreach ($safety_checks as $check) : ?>
          <div style="background:#fff;border:1px solid <?php echo $check['ok'] ? '#c3e6cb' : '#f0c36d'; ?>;border-radius:12px;padding:16px;">
            <strong><?php echo esc_html($check['title']); ?></strong>
            <p style="margin:.45em 0;color:<?php echo $check['ok'] ? '#0d8f72' : '#9a5b00'; ?>;font-weight:700;"><?php echo $check['ok'] ? 'OK' : '要確認'; ?></p>
            <p style="margin:0;color:#646970;"><?php echo esc_html($check['body']); ?></p>
          </div>
        <?php endforeach; ?>
      </div>

      <h2>使う場所</h2>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;max-width:980px;margin:16px 0 24px;">
        <div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;">
          <strong>投稿画面</strong>
          <p style="margin:.5em 0 0;color:#646970;">右サイドバーの「記事設計」で、記事タイプを選びます。</p>
        </div>
        <div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;">
          <strong>パターン</strong>
          <p style="margin:.5em 0 0;color:#646970;">投稿編集画面の「パターン > 記事テンプレート」から7種類の型を選べます。</p>
        </div>
        <div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;">
          <strong>確認URL</strong>
          <p style="margin:.5em 0 0;color:#646970;">llms.txtはサイトURLの末尾に <code>/llms.txt</code> を付けて確認します。一部AIクローラー向けの任意案内であり、Google AI Overviews等への表示を保証するものではありません。</p>
        </div>
        <div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;">
          <strong>.htaccess</strong>
          <p style="margin:.5em 0 0;color:#646970;">Apache / LiteSpeed環境で必要な場合だけ編集します。<a href="<?php echo esc_url(admin_url('themes.php?page=bunsirube-htaccess')); ?>">.htaccess編集画面を開く</a></p>
        </div>
      </div>

      <h2>ヘルプ</h2>
      <table class="widefat striped" style="max-width:860px;margin:16px 0 24px;">
        <tbody>
          <tr><td>テーマバージョン</td><td><?php echo function_exists('bunsirube_update_status_html') ? bunsirube_update_status_html() : esc_html(BUNSIRUBE_VERSION); ?></td></tr>
          <tr><td>更新情報</td><td><a class="button button-secondary" href="<?php echo esc_url(wp_nonce_url(add_query_arg('bunsirube-refresh-update', '1', admin_url('themes.php?page=bunsirube')), 'bunsirube_refresh_update')); ?>">更新情報を再取得</a></td></tr>
          <tr><td>よくある質問</td><td>既存記事は消えません。テーマ変更前にバックアップを取ってから有効化してください。</td></tr>
          <tr><td>サポート範囲</td><td>ZIP導入、基本設定、記事型、文標ショートコードの使い方を対象にしています。</td></tr>
          <tr><td>更新履歴</td><td>更新内容は購入ページとREADMEに記載します。</td></tr>
        </tbody>
      </table>
      <form method="post" action="options.php">
        <?php settings_fields('bunsirube_options_group'); ?>
        <table class="form-table" role="presentation">
          <tr>
            <th scope="row"><label for="bunsirube-color-preset">デザインプリセット</label></th>
            <td>
              <select id="bunsirube-color-preset" name="bunsirube_options[color_preset]">
                <option value="plain" <?php selected($options['color_preset'], 'plain'); ?>>Plain（文章重視）</option>
                <option value="soft" <?php selected($options['color_preset'], 'soft'); ?>>Soft（やわらかいブログ向け）</option>
                <option value="sharp" <?php selected($options['color_preset'], 'sharp'); ?>>Sharp（比較・商品紹介向け）</option>
              </select>
            </td>
          </tr>
          <tr>
            <th scope="row"><label for="bunsirube-main-color">メインカラー</label></th>
            <td>
              <input id="bunsirube-main-color" type="color" name="bunsirube_options[main_color]" value="<?php echo esc_attr($options['main_color']); ?>">
              <p class="description">ボタン、リンク、見出しアクセントに使う色。</p>
            </td>
          </tr>
          <tr>
            <th scope="row"><label for="bunsirube-text-color">文字色</label></th>
            <td>
              <input id="bunsirube-text-color" type="color" name="bunsirube_options[text_color]" value="<?php echo esc_attr($options['text_color']); ?>">
              <p class="description">本文やタイトルの基本色。</p>
            </td>
          </tr>
          <tr>
            <th scope="row"><label for="bunsirube-ga4-id">GA4 測定ID</label></th>
            <td><input id="bunsirube-ga4-id" class="regular-text" name="bunsirube_options[ga4_id]" value="<?php echo esc_attr($options['ga4_id']); ?>" placeholder="G-XXXXXXXXXX"></td>
          </tr>
          <tr>
            <th scope="row"><label for="bunsirube-gsc">Search Console 認証コード</label></th>
            <td><input id="bunsirube-gsc" class="regular-text" name="bunsirube_options[gsc_verification]" value="<?php echo esc_attr($options['gsc_verification']); ?>"></td>
          </tr>
          <tr>
            <th scope="row">SEO・SNS出力</th>
            <td>
              <label><input type="checkbox" name="bunsirube_options[output_meta_tags]" value="1" <?php checked($options['output_meta_tags'], '1'); ?>> 基本メタタグを出力する</label><br>
              <label><input type="checkbox" name="bunsirube_options[output_ogp]" value="1" <?php checked($options['output_ogp'], '1'); ?>> OGP / Twitterカードを出力する</label>
              <p class="description">SEOプラグインを使っている場合は、重複を避けるためOFFにできます。</p>
            </td>
          </tr>
          <tr>
            <th scope="row">構造化データ</th>
            <td>
              <label><input type="checkbox" name="bunsirube_options[output_json_ld]" value="1" <?php checked($options['output_json_ld'], '1'); ?>> JSON-LDを出力する</label><br>
              <label><input type="checkbox" name="bunsirube_options[output_faq_json_ld]" value="1" <?php checked($options['output_faq_json_ld'], '1'); ?>> FAQPage JSON-LDを出力する</label><br>
              <label><input type="checkbox" name="bunsirube_options[output_llms]" value="1" <?php checked($options['output_llms'], '1'); ?>> /llms.txtを出力する</label>
              <p class="description">既存サイトで同じ出力がある場合は、必要なものだけONにしてください。llms.txtは一部AIクローラー向けの任意案内であり、Google AI Overviews等への表示保証ではありません。</p>
            </td>
          </tr>
          <tr>
            <th scope="row">自動ブログカード</th>
            <td>
              <label><input type="checkbox" name="bunsirube_options[auto_blog_cards]" value="1" <?php checked($options['auto_blog_cards'], '1'); ?>> URLだけの行を自動でブログカードにする</label>
              <p class="description">内部リンクは記事情報を使います。外部リンクはタイトル等を短時間だけ取得し、取得できない場合はURL表示に戻します。不要な場合はOFFにできます。</p>
            </td>
          </tr>
          <tr>
            <th scope="row">内部アクセス解析</th>
            <td>
              <label><input type="checkbox" name="bunsirube_options[internal_analytics]" value="1" <?php checked($options['internal_analytics'], '1'); ?>> 内部アクセス解析を使う</label>
              <p class="description">記事ごとのPVと流入元ホストをWordPress内に保存します。個人単位の追跡はしません。初期状態ではOFFです。</p>
              <p class="description">プライバシーポリシー文例: 当サイトでは、記事ごとの閲覧数と流入元ホストをWordPress内に保存する場合があります。個人を特定する目的では利用しません。</p>
            </td>
          </tr>
          <tr>
            <th scope="row">軽量キャッシュ</th>
            <td>
              <label><input type="checkbox" name="bunsirube_options[static_cache]" value="1" <?php checked($options['static_cache'], '1'); ?> <?php disabled($options['internal_analytics'], '1'); ?>> 未ログイン閲覧者向けに簡易キャッシュを使う</label>
              <p class="description">内部アクセス解析をONにしている間は、PV計測のズレを避けるためキャッシュは使いません。</p>
            </td>
          </tr>
          <tr>
            <th scope="row">フッター表記</th>
            <td>
              <label><input type="checkbox" name="bunsirube_options[show_footer_credit]" value="1" <?php checked($options['show_footer_credit'], '1'); ?>> フッターに「Powered by 文標」を表示する</label>
              <p class="description">有料テーマとして使いやすいよう、初期状態では表示しません。</p>
            </td>
          </tr>
          <tr>
            <th scope="row"><label for="bunsirube-license-serial">シリアルナンバー</label></th>
            <td>
              <input id="bunsirube-license-serial" class="regular-text" name="bunsirube_options[license_serial]" value="<?php echo esc_attr($options['license_serial']); ?>" placeholder="BUN-XXXX-XXXX-XXXX-XXXX">
              <p class="description">購入後メールに記載されているシリアルナンバー。</p>
            </td>
          </tr>
          <tr>
            <th scope="row"><label for="bunsirube-license-email">購入メールアドレス</label></th>
            <td><input id="bunsirube-license-email" class="regular-text" type="email" name="bunsirube_options[license_email]" value="<?php echo esc_attr($options['license_email']); ?>" placeholder="you@example.com"></td>
          </tr>
          <tr>
            <th scope="row"><label for="bunsirube-license-purchase">購入ID</label></th>
            <td>
              <input id="bunsirube-license-purchase" class="regular-text" name="bunsirube_options[license_purchase]" value="<?php echo esc_attr($options['license_purchase']); ?>" placeholder="pi_... / cs_... / sub_...">
              <p class="description">購入後メールに記載されている購入ID。ライセンス確認時は、シリアル、メールアドレス、購入IDをよへラボのサーバーへ送信します。</p>
            </td>
          </tr>
          <tr>
            <th scope="row"><label for="bunsirube-llms-extra">llms.txt 追加メモ</label></th>
            <td><textarea id="bunsirube-llms-extra" class="large-text" rows="6" name="bunsirube_options[llms_extra]"><?php echo esc_textarea($options['llms_extra']); ?></textarea></td>
          </tr>
        </table>
        <?php submit_button(); ?>
      </form>
    </div>
    <?php
}

function bunsirube_active_seo_plugins() {
    $active = (array) get_option('active_plugins', array());
    if (is_multisite()) {
        $active = array_merge($active, array_keys((array) get_site_option('active_sitewide_plugins', array())));
    }

    $known = array(
        'wordpress-seo/wp-seo.php' => 'Yoast SEO',
        'seo-by-rank-math/rank-math.php' => 'Rank Math SEO',
        'all-in-one-seo-pack/all_in_one_seo_pack.php' => 'All in One SEO',
        'autodescription/autodescription.php' => 'The SEO Framework',
        'wp-seopress/seopress.php' => 'SEOPress',
    );

    $found = array();
    foreach ($known as $plugin => $label) {
        if (in_array($plugin, $active, true)) {
            $found[] = $label;
        }
    }
    return $found;
}

function bunsirube_active_cache_plugins() {
    $active = (array) get_option('active_plugins', array());
    if (is_multisite()) {
        $active = array_merge($active, array_keys((array) get_site_option('active_sitewide_plugins', array())));
    }

    $known = array(
        'wp-super-cache/wp-cache.php' => 'WP Super Cache',
        'w3-total-cache/w3-total-cache.php' => 'W3 Total Cache',
        'wp-rocket/wp-rocket.php' => 'WP Rocket',
        'litespeed-cache/litespeed-cache.php' => 'LiteSpeed Cache',
        'wp-fastest-cache/wpFastestCache.php' => 'WP Fastest Cache',
        'sg-cachepress/sg-cachepress.php' => 'Speed Optimizer',
        'autoptimize/autoptimize.php' => 'Autoptimize',
    );

    $found = array();
    foreach ($known as $plugin => $label) {
        if (in_array($plugin, $active, true)) {
            $found[] = $label;
        }
    }
    return $found;
}

function bunsirube_legacy_shortcode_count() {
    global $wpdb;
    $legacy_prefix = '[' . 'a' . 'io_';
    return (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status NOT IN ('trash','auto-draft') AND post_content LIKE %s",
        '%' . $wpdb->esc_like($legacy_prefix) . '%'
    ));
}

function bunsirube_safety_checks($options, $seo_plugins, $cache_plugins) {
    $seo_outputs_on = $options['output_meta_tags'] === '1' || $options['output_ogp'] === '1' || $options['output_json_ld'] === '1' || $options['output_faq_json_ld'] === '1';
    $legacy_count = bunsirube_legacy_shortcode_count();
    $theme = wp_get_theme();
    $using_child = $theme->get_stylesheet() !== $theme->get_template();
    $htaccess = function_exists('bunsirube_htaccess_target') ? bunsirube_htaccess_target() : null;

    return array(
        array(
            'title' => 'WordPress / PHP',
            'ok'    => version_compare(get_bloginfo('version'), '6.5', '>=') && version_compare(PHP_VERSION, '8.0', '>='),
            'body'  => '推奨はWordPress 6.5以上 / PHP 8.0以上です。古い環境は購入前・有効化前に更新してください。',
        ),
        array(
            'title' => 'SEO出力の重複',
            'ok'    => empty($seo_plugins) || !$seo_outputs_on,
            'body'  => empty($seo_plugins) ? '主要SEOプラグインは検出されていません。' : 'SEOプラグインを使う場合は、文標側のメタタグ / OGP / JSON-LDをOFFにしてください。',
        ),
        array(
            'title' => 'キャッシュの重複',
            'ok'    => empty($cache_plugins) || $options['static_cache'] !== '1',
            'body'  => empty($cache_plugins) ? '主要キャッシュ系プラグインは検出されていません。' : 'キャッシュ系プラグインと文標の簡易キャッシュは重ねないでください。',
        ),
        array(
            'title' => '旧ショートコード残り',
            'ok'    => $legacy_count === 0,
            'body'  => $legacy_count === 0 ? '古い互換ショートコードは検出されていません。' : $legacy_count . '件の記事に古い互換ショートコードが残っています。公開前に文標のショートコードへ置き換えてください。',
        ),
        array(
            'title' => '自動ブログカード',
            'ok'    => true,
            'body'  => $options['auto_blog_cards'] === '1' ? '外部URLはタイトル等を短時間だけ取得します。不要な場合はOFFにできます。' : '自動変換はOFFです。必要な記事だけショートコードで入れられます。',
        ),
        array(
            'title' => '改造方法',
            'ok'    => $using_child,
            'body'  => $using_child ? '子テーマ利用中です。親テーマ更新で改造が消えにくい状態です。' : 'CSSや関数を改造する場合は、親テーマを直接編集せず子テーマを使ってください。',
        ),
        array(
            'title' => '.htaccess編集',
            'ok'    => !$htaccess || $htaccess['editable'],
            'body'  => !$htaccess ? '編集機能は読み込まれていません。' : $htaccess['message'],
        ),
    );
}
