<?php
/**
 * Theme auto-updater.
 *
 * Checks yohelab.com for a newer version and shows the update notice
 * in WP Admin > Appearance > Themes, just like themes from WordPress.org.
 *
 * Update manifest URL: https://yohelab.com/api/theme-update/bunsirube.json
 * Expected JSON shape:
 *   {
 *     "version": "0.2.8",
 *     "details_url": "https://yohelab.com/lp/bunsirube/",
 *     "package": "https://yohelab.com/api/theme-download"
 *   }
 *
 * @package Bunsirube
 */

if (!defined('ABSPATH')) {
    exit;
}

define('BUNSIRUBE_UPDATE_URL', 'https://yohelab.com/api/theme-update/bunsirube.json');
define('BUNSIRUBE_THEME_SLUG', 'bunsirube');

/**
 * Fetch update manifest with 12-hour transient cache.
 *
 * @return array|false Associative array from JSON, or false on failure.
 */
function bunsirube_fetch_update_data() {
    $cached = get_transient('bunsirube_update_data');
    if (is_array($cached)) {
        return $cached;
    }

    $response = wp_remote_get(BUNSIRUBE_UPDATE_URL, array(
        'timeout'    => 10,
        'user-agent' => 'Bunsirube/' . BUNSIRUBE_VERSION . '; WordPress/' . get_bloginfo('version'),
        'headers'    => array('Accept' => 'application/json'),
    ));

    if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) {
        return false;
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!isset($data['version'])) {
        return false;
    }

    // サニタイズ
    $clean = array(
        'version'     => sanitize_text_field($data['version']),
        'details_url' => esc_url_raw($data['details_url'] ?? ''),
        'package'     => esc_url_raw($data['package'] ?? ''),
    );

    set_transient('bunsirube_update_data', $clean, 12 * HOUR_IN_SECONDS);
    return $clean;
}

function bunsirube_update_package_url($base_url) {
    if (!$base_url) {
        return '';
    }

    $options = bunsirube_get_options();
    if (empty($options['license_serial']) || empty($options['license_email']) || empty($options['license_purchase'])) {
        return '';
    }

    $license = function_exists('bunsirube_license_status') ? bunsirube_license_status() : array();
    if (!empty($license['download_token'])) {
        return add_query_arg(array('token' => $license['download_token']), $base_url);
    }

    return '';
}

/**
 * Inject update info into the WordPress theme update transient.
 *
 * @param object $transient The update_themes transient object.
 * @return object
 */
add_filter('pre_set_site_transient_update_themes', 'bunsirube_check_for_update');
function bunsirube_check_for_update($transient) {
    if (empty($transient->checked)) {
        return $transient;
    }

    // このテーマが有効化されているときだけ動かす
    if (!isset($transient->checked[BUNSIRUBE_THEME_SLUG])) {
        return $transient;
    }

    $data = bunsirube_fetch_update_data();
    if (!$data) {
        return $transient;
    }

    if (version_compare($data['version'], BUNSIRUBE_VERSION, '>')) {
        $package = bunsirube_update_package_url($data['package']);
        if (!$package) {
            unset($transient->response[BUNSIRUBE_THEME_SLUG]);
            return $transient;
        }

        $transient->response[BUNSIRUBE_THEME_SLUG] = array(
            'theme'       => BUNSIRUBE_THEME_SLUG,
            'new_version' => $data['version'],
            'url'         => $data['details_url'],
            'package'     => $package,
            'requires'    => '6.5',
            'requires_php'=> '8.0',
        );
    } else {
        // アップデート不要の場合は no_update に登録（通知を出さない）
        $transient->no_update[BUNSIRUBE_THEME_SLUG] = array(
            'theme'       => BUNSIRUBE_THEME_SLUG,
            'new_version' => BUNSIRUBE_VERSION,
            'url'         => $data['details_url'],
            'package'     => bunsirube_update_package_url($data['package']),
        );
    }

    return $transient;
}

/**
 * テーマ詳細ポップアップに更新ページへのリンクを差し込む。
 *
 * @param false|object $override  Allows bypassing the Themes API.
 * @param string       $action    API action requested.
 * @param object       $args      Request arguments.
 * @return false|object
 */
add_filter('themes_api', 'bunsirube_themes_api', 10, 3);
function bunsirube_themes_api($override, $action, $args) {
    if ($action !== 'theme_information' || empty($args->slug) || $args->slug !== BUNSIRUBE_THEME_SLUG) {
        return $override;
    }

    $data = bunsirube_fetch_update_data();
    if (!$data) {
        return $override;
    }

    return (object) array(
        'name'          => '文標',
        'slug'          => BUNSIRUBE_THEME_SLUG,
        'version'       => $data['version'],
        'author'        => 'よへラボ',
        'homepage'      => 'https://yohelab.com/',
        'sections'      => array(
            'description' => '比較記事・レビュー記事・FAQ記事を迷わず書き始めるための軽量WordPressテーマ。記事の型、FAQ、著者情報、比較表、CTAを最初から使えます。',
            'changelog'   => sprintf(
                '<p><a href="%s" target="_blank" rel="noopener noreferrer">変更履歴を見る →</a></p>',
                esc_url($data['details_url'])
            ),
        ),
        'download_link' => bunsirube_update_package_url($data['package']),
        'requires'      => '6.5',
        'requires_php'  => '8.0',
        'last_updated'  => current_time('Y-m-d'),
        'external'      => true,
    );
}

/**
 * アップデート完了後にキャッシュを消去する。
 *
 * @param WP_Upgrader $upgrader  Upgrader instance.
 * @param array       $hook_extra Extra data about the upgrade.
 */
add_action('upgrader_process_complete', 'bunsirube_purge_update_cache', 10, 2);
function bunsirube_purge_update_cache($upgrader, $hook_extra) {
    if (
        isset($hook_extra['type'], $hook_extra['themes']) &&
        $hook_extra['type'] === 'theme' &&
        in_array(BUNSIRUBE_THEME_SLUG, (array) $hook_extra['themes'], true)
    ) {
        delete_transient('bunsirube_update_data');
    }
}

/**
 * アップデートがあるがシリアル未設定の場合に管理画面でお知らせを表示する。
 */
add_action('admin_notices', 'bunsirube_update_nag');
function bunsirube_update_nag() {
    $screen = get_current_screen();
    if (!$screen || !in_array($screen->id, array('themes', 'appearance_page_bunsirube'), true)) {
        return;
    }
    $data = bunsirube_fetch_update_data();
    if (!$data || !version_compare($data['version'], BUNSIRUBE_VERSION, '>')) {
        return;
    }
    $options = bunsirube_get_options();
    if (
        !empty($options['license_serial']) &&
        !empty($options['license_email']) &&
        !empty($options['license_purchase'])
    ) {
        return; // シリアル設定済み → WP標準の更新通知に任せる
    }
    printf(
        '<div class="notice notice-warning is-dismissible"><p>' .
        /* translators: %1$s: new version, %2$s: settings URL */
        esc_html__('文標 %1$s が利用可能です。アップデートするには %2$s でシリアルナンバーを入力してください。', 'bunsirube') .
        '</p></div>',
        esc_html($data['version']),
        '<a href="' . esc_url(admin_url('themes.php?page=bunsirube')) . '">' . esc_html__('文標 設定', 'bunsirube') . '</a>'
    );
}

/**
 * 管理画面の設定ページに「アップデート確認」ボタンを追加するためのリンク。
 * settings.php から呼び出し可能なヘルパー。
 *
 * @return string HTML
 */
function bunsirube_update_status_html() {
    $data    = bunsirube_fetch_update_data();
    $current = BUNSIRUBE_VERSION;

    if (!$data) {
        $label = esc_html__('更新情報を取得できませんでした', 'bunsirube');
        $color = '#b8bfca';
    } elseif (version_compare($data['version'], $current, '>')) {
        $label = sprintf(
            /* translators: 1: current version, 2: new version */
            esc_html__('現在 %1$s → 新バージョン %2$s あり', 'bunsirube'),
            esc_html($current),
            esc_html($data['version'])
        );
        $color = '#0d8f72';
    } else {
        $label = sprintf(
            /* translators: version number */
            esc_html__('最新版（%s）を使用中', 'bunsirube'),
            esc_html($current)
        );
        $color = '#536174';
    }

    return '<span style="color:' . esc_attr($color) . ';font-weight:700;">' . $label . '</span>';
}
