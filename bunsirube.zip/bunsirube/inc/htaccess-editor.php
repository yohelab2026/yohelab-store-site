<?php
/**
 * Safe .htaccess editor for Apache sites.
 *
 * @package Bunsirube
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', 'bunsirube_htaccess_menu');
function bunsirube_htaccess_menu() {
    add_theme_page(
        __('文標 .htaccess', 'bunsirube'),
        __('.htaccess', 'bunsirube'),
        'manage_options',
        'bunsirube-htaccess',
        'bunsirube_htaccess_page'
    );
}

add_action('admin_init', 'bunsirube_handle_htaccess_actions');
function bunsirube_handle_htaccess_actions() {
    if (!empty($_GET['bunsirube_htaccess_download'])) {
        bunsirube_handle_htaccess_download();
        return;
    }

    if (
        empty($_POST['bunsirube_htaccess_action']) ||
        !current_user_can('manage_options') ||
        !check_admin_referer('bunsirube_htaccess_action')
    ) {
        return;
    }

    $target = bunsirube_htaccess_target();
    if (!$target['editable']) {
        bunsirube_htaccess_redirect('blocked');
    }

    $action = sanitize_key(wp_unslash($_POST['bunsirube_htaccess_action']));
    if ($action === 'save') {
        $content = bunsirube_normalize_htaccess_content(wp_unslash($_POST['bunsirube_htaccess_content'] ?? ''));
        $validation = bunsirube_validate_htaccess_content($content);
        if (!$validation['ok']) {
            bunsirube_htaccess_redirect($validation['code']);
        }

        $current = bunsirube_read_htaccess($target['path']);
        bunsirube_store_htaccess_backup($current, 'save');

        if (false === file_put_contents($target['path'], $content, LOCK_EX)) {
            bunsirube_htaccess_redirect('write_failed');
        }
        bunsirube_htaccess_redirect('saved');
    }

    if ($action === 'restore') {
        $backup_id = sanitize_text_field(wp_unslash($_POST['bunsirube_htaccess_backup_id'] ?? ''));
        $backup = bunsirube_find_htaccess_backup($backup_id);
        if (!$backup) {
            bunsirube_htaccess_redirect('backup_missing');
        }

        $current = bunsirube_read_htaccess($target['path']);
        bunsirube_store_htaccess_backup($current, 'restore');

        if (false === file_put_contents($target['path'], $backup['content'], LOCK_EX)) {
            bunsirube_htaccess_redirect('write_failed');
        }
        bunsirube_htaccess_redirect('restored');
    }
}

function bunsirube_htaccess_page() {
    if (!function_exists('submit_button')) {
        require_once ABSPATH . 'wp-admin/includes/template.php';
    }

    $target = bunsirube_htaccess_target();
    $content = $target['readable'] ? bunsirube_read_htaccess($target['path']) : '';
    $backups = bunsirube_htaccess_backups();
    $server = sanitize_text_field(wp_unslash($_SERVER['SERVER_SOFTWARE'] ?? ''));
    $is_apache = stripos($server, 'apache') !== false || stripos($server, 'litespeed') !== false;
    ?>
    <div class="wrap">
      <h1>文標 .htaccess</h1>
      <?php bunsirube_htaccess_notice(); ?>

      <div class="notice notice-warning" style="max-width:980px;">
        <p><strong>.htaccessはサイト全体に影響します。</strong> 1文字のミスで、トップページや管理画面まで表示できなくなる場合があります。変更前の内容は自動でバックアップします。</p>
        <p><strong>管理画面に入れなくなった場合、この画面から復元できません。</strong> 保存前に現在の内容を手元にも保存してください。</p>
      </div>

      <?php if (!$is_apache) : ?>
        <div class="notice notice-info" style="max-width:980px;">
          <p>現在のサーバー情報ではApache / LiteSpeedを確認できませんでした。Nginxなどでは.htaccessを編集しても反映されないことがあります。</p>
        </div>
      <?php endif; ?>

      <table class="widefat striped" style="max-width:980px;margin:16px 0 24px;">
        <tbody>
          <tr><td>編集対象</td><td><code><?php echo esc_html($target['path']); ?></code></td></tr>
          <tr><td>状態</td><td><?php echo esc_html($target['message']); ?></td></tr>
          <tr><td>バックアップ</td><td>保存前の内容をWordPress内に最大8件まで残し、必要ならテキストとしてダウンロードできます。</td></tr>
        </tbody>
      </table>

      <?php if ($target['editable']) : ?>
        <?php if ($target['readable']) : ?>
          <p>
            <a class="button button-secondary" href="<?php echo esc_url(bunsirube_htaccess_download_url('current')); ?>">現在の内容をダウンロード</a>
          </p>
        <?php endif; ?>
        <form method="post">
          <?php wp_nonce_field('bunsirube_htaccess_action'); ?>
          <input type="hidden" name="bunsirube_htaccess_action" value="save">
          <textarea name="bunsirube_htaccess_content" class="large-text code" rows="22" spellcheck="false"><?php echo esc_textarea($content); ?></textarea>
          <p class="description">PHPコード、HTML、巨大な内容は保存できません。WordPress標準のRewriteルールやリダイレクト、キャッシュ系プラグインが書いた内容を壊さないようにしてください。</p>
          <?php submit_button('バックアップして保存', 'primary'); ?>
        </form>
      <?php else : ?>
        <div class="notice notice-error" style="max-width:980px;">
          <p><?php echo esc_html($target['message']); ?></p>
        </div>
        <?php if ($target['readable']) : ?>
          <textarea class="large-text code" rows="22" readonly><?php echo esc_textarea($content); ?></textarea>
        <?php endif; ?>
      <?php endif; ?>

      <h2>バックアップから戻す</h2>
      <?php if ($backups) : ?>
        <table class="widefat striped" style="max-width:980px;">
          <thead><tr><th>日時</th><th>操作</th><th>サイズ</th><th>保存</th><th>戻す</th></tr></thead>
          <tbody>
            <?php foreach ($backups as $backup) : ?>
              <tr>
                <td><?php echo esc_html($backup['time_label']); ?></td>
                <td><?php echo esc_html($backup['reason']); ?></td>
                <td><?php echo esc_html(size_format(strlen($backup['content']))); ?></td>
                <td><a class="button button-secondary" href="<?php echo esc_url(bunsirube_htaccess_download_url($backup['id'])); ?>">ダウンロード</a></td>
                <td>
                  <?php if ($target['editable']) : ?>
                    <form method="post" style="margin:0;">
                      <?php wp_nonce_field('bunsirube_htaccess_action'); ?>
                      <input type="hidden" name="bunsirube_htaccess_action" value="restore">
                      <input type="hidden" name="bunsirube_htaccess_backup_id" value="<?php echo esc_attr($backup['id']); ?>">
                      <button type="submit" class="button button-secondary">この内容に戻す</button>
                    </form>
                  <?php else : ?>
                    <span>編集不可</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php else : ?>
        <p>まだバックアップはありません。</p>
      <?php endif; ?>
    </div>
    <?php
}

function bunsirube_htaccess_target() {
    if (defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT) {
        return array(
            'path' => '',
            'readable' => false,
            'editable' => false,
            'message' => 'DISALLOW_FILE_EDIT が有効なため、テーマからのファイル編集は停止しています。',
        );
    }

    if (!function_exists('get_home_path')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }

    $root = wp_normalize_path(function_exists('get_home_path') ? get_home_path() : ABSPATH);
    $root = trailingslashit($root);
    $path = $root . '.htaccess';
    $root_real = realpath($root);
    $path_real = file_exists($path) ? realpath($path) : false;

    if (!$root_real) {
        return array('path' => $path, 'readable' => false, 'editable' => false, 'message' => 'サイトのルートディレクトリを確認できません。');
    }

    if ($path_real && strpos(wp_normalize_path($path_real), wp_normalize_path($root_real)) !== 0) {
        return array('path' => $path, 'readable' => false, 'editable' => false, 'message' => '.htaccess の場所がサイトルート外に見えるため、編集を止めています。');
    }

    $exists = file_exists($path);
    $readable = $exists && is_readable($path);
    $writable = $exists ? is_writable($path) : is_writable($root);

    if (!$exists && !$writable) {
        return array('path' => $path, 'readable' => false, 'editable' => false, 'message' => '.htaccess がなく、サイトルートにも書き込めません。');
    }
    if ($exists && !$readable) {
        return array('path' => $path, 'readable' => false, 'editable' => false, 'message' => '.htaccess を読み取れません。');
    }
    if (!$writable) {
        return array('path' => $path, 'readable' => $readable, 'editable' => false, 'message' => '.htaccess に書き込めません。サーバーの権限を確認してください。');
    }

    return array(
        'path' => $path,
        'readable' => $readable,
        'editable' => true,
        'message' => $exists ? '読み書きできます。保存時に自動バックアップを作成します。' : '.htaccess はまだありません。保存すると新規作成します。',
    );
}

function bunsirube_read_htaccess($path) {
    if (!$path || !file_exists($path) || !is_readable($path)) {
        return '';
    }
    $content = file_get_contents($path);
    return is_string($content) ? $content : '';
}

function bunsirube_normalize_htaccess_content($content) {
    $content = str_replace(array("\r\n", "\r"), "\n", (string) $content);
    return rtrim($content) . "\n";
}

function bunsirube_validate_htaccess_content($content) {
    if (strpos($content, "\0") !== false) {
        return array('ok' => false, 'code' => 'invalid_null');
    }
    if (strlen($content) > 200000) {
        return array('ok' => false, 'code' => 'too_large');
    }
    if (preg_match('/<\?(php|=)?/i', $content)) {
        return array('ok' => false, 'code' => 'php_blocked');
    }
    return array('ok' => true, 'code' => '');
}

function bunsirube_htaccess_backups() {
    $backups = get_option('bunsirube_htaccess_backups', array());
    return is_array($backups) ? $backups : array();
}

function bunsirube_store_htaccess_backup($content, $reason) {
    $content = (string) $content;
    $backups = bunsirube_htaccess_backups();
    array_unshift($backups, array(
        'id' => function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : uniqid('bunsirube-', true),
        'time' => time(),
        'time_label' => date_i18n('Y-m-d H:i:s'),
        'reason' => $reason === 'restore' ? '復元前' : '保存前',
        'content' => $content,
    ));
    $backups = array_slice($backups, 0, 8);
    update_option('bunsirube_htaccess_backups', $backups, false);
}

function bunsirube_find_htaccess_backup($id) {
    foreach (bunsirube_htaccess_backups() as $backup) {
        if (!empty($backup['id']) && hash_equals((string) $backup['id'], (string) $id)) {
            return $backup;
        }
    }
    return null;
}

function bunsirube_htaccess_download_url($id) {
    return wp_nonce_url(
        add_query_arg(
            array(
                'page' => 'bunsirube-htaccess',
                'bunsirube_htaccess_download' => rawurlencode((string) $id),
            ),
            admin_url('themes.php')
        ),
        'bunsirube_htaccess_download'
    );
}

function bunsirube_handle_htaccess_download() {
    if (!current_user_can('manage_options')) {
        wp_die('Forbidden', 'Forbidden', array('response' => 403));
    }
    $nonce = sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'bunsirube_htaccess_download')) {
        wp_die('Invalid request', 'Invalid request', array('response' => 403));
    }

    $download_id = sanitize_text_field(wp_unslash($_GET['bunsirube_htaccess_download'] ?? ''));
    $content = '';
    $filename = 'bunsirube-htaccess-backup.txt';

    if ($download_id === 'current') {
        $target = bunsirube_htaccess_target();
        if (!$target['readable']) {
            wp_die('.htaccess を読み取れません。', '.htaccess を読み取れません。', array('response' => 404));
        }
        $content = bunsirube_read_htaccess($target['path']);
        $filename = 'bunsirube-htaccess-current-' . gmdate('Ymd-His') . '.txt';
    } else {
        $backup = bunsirube_find_htaccess_backup($download_id);
        if (!$backup) {
            wp_die('指定したバックアップが見つかりません。', '指定したバックアップが見つかりません。', array('response' => 404));
        }
        $content = (string) $backup['content'];
        $filename = 'bunsirube-htaccess-backup-' . gmdate('Ymd-His', (int) ($backup['time'] ?? time())) . '.txt';
    }

    nocache_headers();
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo $content;
    exit;
}

function bunsirube_htaccess_redirect($status) {
    wp_safe_redirect(add_query_arg('bunsirube-htaccess-status', rawurlencode($status), admin_url('themes.php?page=bunsirube-htaccess')));
    exit;
}

function bunsirube_htaccess_notice() {
    $status = sanitize_key(wp_unslash($_GET['bunsirube-htaccess-status'] ?? ''));
    if (!$status) {
        return;
    }

    $messages = array(
        'saved' => array('success', '.htaccess を保存しました。表示に異常があれば、バックアップから戻してください。'),
        'restored' => array('success', 'バックアップ内容へ戻しました。'),
        'blocked' => array('error', '現在の環境では .htaccess を編集できません。'),
        'write_failed' => array('error', '.htaccess への書き込みに失敗しました。'),
        'backup_missing' => array('error', '指定したバックアップが見つかりません。'),
        'invalid_null' => array('error', '保存内容に不正な制御文字が含まれています。'),
        'too_large' => array('error', '.htaccess としては内容が大きすぎます。'),
        'php_blocked' => array('error', '.htaccess にPHPコードは保存できません。'),
    );
    if (empty($messages[$status])) {
        return;
    }
    list($type, $message) = $messages[$status];
    echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible" style="max-width:980px;"><p>' . esc_html($message) . '</p></div>';
}
