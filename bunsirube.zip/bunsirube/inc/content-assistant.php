<?php
/**
 * Lightweight per-post writing assistant.
 *
 * @package Bunsirube
 */

if (!defined('ABSPATH')) {
    exit;
}

function bunsirube_add_content_assistant_box() {
    add_meta_box(
        'bunsirube-content-assistant',
        __('文標 記事設計メモ', 'bunsirube'),
        'bunsirube_render_content_assistant_box',
        array('post', 'page'),
        'side',
        'high'
    );
}

add_action('init', 'bunsirube_register_content_assistant_meta');
function bunsirube_register_content_assistant_meta() {
    $text_fields = array('type', 'reader', 'intent', 'conclusion', 'evidence', 'caution', 'cta');
    foreach ($text_fields as $field) {
        register_post_meta('', '_aio_assistant_' . $field, array(
            'type'              => 'string',
            'single'            => true,
            'show_in_rest'      => true,
            'sanitize_callback' => 'sanitize_textarea_field',
            'auth_callback'     => static function () {
                return current_user_can('edit_posts');
            },
        ));
    }

    foreach (array_keys(bunsirube_content_assistant_checks()) as $field) {
        register_post_meta('', '_aio_assistant_check_' . $field, array(
            'type'              => 'string',
            'single'            => true,
            'show_in_rest'      => true,
            'sanitize_callback' => 'sanitize_text_field',
            'auth_callback'     => static function () {
                return current_user_can('edit_posts');
            },
        ));
    }
}

add_action('enqueue_block_editor_assets', 'bunsirube_enqueue_content_assistant_sidebar');
function bunsirube_enqueue_content_assistant_sidebar() {
    wp_enqueue_script(
        'bunsirube-editor-sidebar',
        BUNSIRUBE_URI . '/assets/js/editor-sidebar.js',
        array('wp-plugins', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-data', 'wp-i18n', 'wp-blocks', 'wp-block-editor'),
        BUNSIRUBE_VERSION,
        true
    );
}

function bunsirube_content_assistant_defaults() {
    return array(
        'type'       => 'basic',
        'reader'     => '',
        'intent'     => '',
        'conclusion' => '',
        'evidence'   => '',
        'caution'    => '',
        'cta'        => '',
        'checked'    => array(),
    );
}

function bunsirube_get_content_assistant($post_id) {
    $saved = get_post_meta($post_id, '_aio_content_assistant', true);
    $saved = is_array($saved) ? $saved : array();
    $data  = wp_parse_args($saved, bunsirube_content_assistant_defaults());

    $data['checked'] = is_array($data['checked']) ? $data['checked'] : array();
    return $data;
}

function bunsirube_content_assistant_checks() {
    return array(
        'title'      => __('タイトルが具体的', 'bunsirube'),
        'conclusion' => __('最初に答えを書いた', 'bunsirube'),
        'ai_answer'  => __('AI検索にも読まれやすい短い答えを置いた', 'bunsirube'),
        'evidence'   => __('理由・比較を書いた', 'bunsirube'),
        'caution'    => __('注意点を書いた', 'bunsirube'),
        'faq'        => __('FAQを入れた', 'bunsirube'),
        'source'     => __('出典・参考リンクを書いた', 'bunsirube'),
        'compare'    => __('必要なら比較表を入れた', 'bunsirube'),
        'summary'    => __('最後にまとめた', 'bunsirube'),
        'cta'        => __('最後の行動が分かる', 'bunsirube'),
        'mobile'     => __('スマホで長すぎないか見た', 'bunsirube'),
        'updated'    => __('情報が古くないか見た', 'bunsirube'),
    );
}

function bunsirube_render_content_assistant_box($post) {
    $data   = bunsirube_get_content_assistant($post->ID);
    $checks = bunsirube_content_assistant_checks();
    $score  = count(array_intersect(array_keys($checks), $data['checked']));
    $total  = count($checks);

    wp_nonce_field('bunsirube_content_assistant_save', 'bunsirube_content_assistant_nonce');
    ?>
    <style>
      .bunsirube-assistant-box{display:grid;gap:10px}
      .bunsirube-assistant-score{padding:10px 12px;border-radius:10px;background:#ecfdf5;border:1px solid #b7ead6;font-weight:700;color:#047857}
      .bunsirube-assistant-box label{font-weight:700}
      .bunsirube-assistant-box textarea{width:100%;min-height:58px}
      .bunsirube-assistant-checks{display:grid;gap:8px;margin-top:4px}
      .bunsirube-assistant-checks label{font-weight:400;line-height:1.45}
      .bunsirube-assistant-help{color:#646970;font-size:12px;margin:0}
    </style>
    <div class="bunsirube-assistant-box">
      <div class="bunsirube-assistant-score">
        <?php echo esc_html(sprintf(__('記事準備 %1$d/%2$d', 'bunsirube'), $score, $total)); ?>
      </div>
      <p class="bunsirube-assistant-help">記事を書く前に、読者・検索意図・結論・根拠を固定します。</p>

      <?php
      $fields = array(
        'intent'     => __('この記事で答えること', 'bunsirube'),
        'conclusion' => __('先に出す答え', 'bunsirube'),
        'evidence'   => __('理由・比較・参考リンク', 'bunsirube'),
        'caution'    => __('注意点・補足', 'bunsirube'),
        'cta'        => __('最後に促す行動', 'bunsirube'),
      );
      foreach ($fields as $key => $label) :
          ?>
          <p>
            <label for="bunsirube-assistant-<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label>
            <textarea id="bunsirube-assistant-<?php echo esc_attr($key); ?>" name="aio_content_assistant[<?php echo esc_attr($key); ?>]"><?php echo esc_textarea($data[$key]); ?></textarea>
          </p>
      <?php endforeach; ?>

      <div class="bunsirube-assistant-checks">
        <?php foreach ($checks as $key => $label) : ?>
          <label>
            <input type="checkbox" name="aio_content_assistant[checked][]" value="<?php echo esc_attr($key); ?>" <?php checked(in_array($key, $data['checked'], true)); ?>>
            <?php echo esc_html($label); ?>
          </label>
        <?php endforeach; ?>
      </div>
    </div>
    <?php
}

add_action('save_post', 'bunsirube_save_content_assistant');
function bunsirube_save_content_assistant($post_id) {
    if (!isset($_POST['bunsirube_content_assistant_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['bunsirube_content_assistant_nonce'])), 'bunsirube_content_assistant_save')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $input  = isset($_POST['aio_content_assistant']) && is_array($_POST['aio_content_assistant']) ? wp_unslash($_POST['aio_content_assistant']) : array();
    $checks = bunsirube_content_assistant_checks();

    $data = array(
        'reader'     => sanitize_textarea_field($input['reader'] ?? ''),
        'intent'     => sanitize_textarea_field($input['intent'] ?? ''),
        'conclusion' => sanitize_textarea_field($input['conclusion'] ?? ''),
        'evidence'   => sanitize_textarea_field($input['evidence'] ?? ''),
        'caution'    => sanitize_textarea_field($input['caution'] ?? ''),
        'cta'        => sanitize_textarea_field($input['cta'] ?? ''),
        'checked'    => array(),
    );

    if (!empty($input['checked']) && is_array($input['checked'])) {
        $data['checked'] = array_values(array_intersect(array_map('sanitize_key', $input['checked']), array_keys($checks)));
    }

    update_post_meta($post_id, '_aio_content_assistant', $data);
}
