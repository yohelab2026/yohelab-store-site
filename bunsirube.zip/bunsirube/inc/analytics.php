<?php
/**
 * Lightweight internal analytics.
 *
 * @package Bunsirube
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('template_redirect', 'bunsirube_track_view');
function bunsirube_track_view() {
    if (bunsirube_get_option('internal_analytics', '0') !== '1' || !is_singular() || is_user_logged_in()) {
        return;
    }

    $post_id = get_queried_object_id();
    $views = (int) get_post_meta($post_id, '_bunsirube_views', true);
    update_post_meta($post_id, '_bunsirube_views', $views + 1);

    $ref = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'])) : '';
    if ($ref && strpos($ref, home_url()) !== 0) {
        $host = wp_parse_url($ref, PHP_URL_HOST);
        if ($host) {
            $refs = get_option('bunsirube_referrers', array());
            $refs = is_array($refs) ? $refs : array();
            $refs[$host] = isset($refs[$host]) ? (int) $refs[$host] + 1 : 1;
            arsort($refs);
            update_option('bunsirube_referrers', array_slice($refs, 0, 30, true), false);
        }
    }
}

add_action('init', 'bunsirube_register_analytics_meta');
function bunsirube_register_analytics_meta() {
    foreach (array('cta', 'compare', 'ad', 'blogcard') as $type) {
        register_post_meta('', '_bunsirube_clicks_' . $type, array(
            'type'              => 'integer',
            'single'            => true,
            'show_in_rest'      => true,
            'sanitize_callback' => 'absint',
            'auth_callback'     => static function () {
                return current_user_can('edit_posts');
            },
        ));
    }
}

add_action('wp_dashboard_setup', 'bunsirube_dashboard_widget');
function bunsirube_dashboard_widget() {
    if (bunsirube_get_option('internal_analytics', '0') !== '1') {
        return;
    }
    wp_add_dashboard_widget('bunsirube_analytics', '文標 内部アクセス解析', 'bunsirube_dashboard_widget_render');
}

function bunsirube_dashboard_widget_render() {
    $posts = get_posts(array(
        'posts_per_page' => 5,
        'meta_key'       => '_bunsirube_views',
        'orderby'        => 'meta_value_num',
        'order'          => 'DESC',
        'post_status'    => 'publish',
    ));

    echo '<h3>人気記事</h3><ol>';
    foreach ($posts as $post) {
        $views = (int) get_post_meta($post->ID, '_bunsirube_views', true);
        echo '<li><a href="' . esc_url(get_edit_post_link($post->ID)) . '">' . esc_html(get_the_title($post)) . '</a> - ' . esc_html(number_format_i18n($views)) . ' PV</li>';
    }
    echo '</ol>';

    $refs = get_option('bunsirube_referrers', array());
    if ($refs) {
        echo '<h3>流入元</h3><ol>';
        foreach (array_slice($refs, 0, 5, true) as $host => $count) {
            echo '<li>' . esc_html($host) . ' - ' . esc_html(number_format_i18n((int) $count)) . '</li>';
        }
        echo '</ol>';
    }

    $clicks = get_option('bunsirube_clicks', array());
    if (is_array($clicks) && $clicks) {
        arsort($clicks);
        echo '<h3>導線クリック</h3><ol>';
        foreach (array_slice($clicks, 0, 8, true) as $label => $count) {
            echo '<li>' . esc_html($label) . ' - ' . esc_html(number_format_i18n((int) $count)) . '</li>';
        }
        echo '</ol>';
        echo '<p style="color:#646970;">導線クリックは記事改善のための参考値です。Cookieや個人単位の追跡は使いません。</p>';
    }
}

add_action('rest_api_init', 'bunsirube_register_analytics_routes');
function bunsirube_register_analytics_routes() {
    register_rest_route('bunsirube/v1', '/click', array(
        'methods' => 'POST',
        'callback' => 'bunsirube_track_click',
        'permission_callback' => '__return_true',
        'args' => array(
            'post_id' => array('sanitize_callback' => 'absint'),
            'type'    => array('sanitize_callback' => 'sanitize_key'),
            'label'   => array('sanitize_callback' => 'sanitize_text_field'),
        ),
    ));
}

function bunsirube_track_click(WP_REST_Request $request) {
    if (bunsirube_get_option('internal_analytics', '0') !== '1' || is_user_logged_in()) {
        return new WP_REST_Response(array('ok' => false), 200);
    }

    $post_id = absint($request->get_param('post_id'));
    $type = sanitize_key($request->get_param('type') ?: 'link');
    $label = sanitize_text_field($request->get_param('label') ?: 'unknown');
    if (!$post_id || !in_array($type, array('cta', 'compare', 'ad', 'blogcard'), true)) {
        return new WP_REST_Response(array('ok' => false), 200);
    }

    $post = get_post($post_id);
    if (!$post || $post->post_status !== 'publish') {
        return new WP_REST_Response(array('ok' => false), 200);
    }

    $meta_key = '_bunsirube_clicks_' . $type;
    update_post_meta($post_id, $meta_key, (int) get_post_meta($post_id, $meta_key, true) + 1);

    $clicks = get_option('bunsirube_clicks', array());
    $clicks = is_array($clicks) ? $clicks : array();
    $key = get_the_title($post_id) . ' / ' . strtoupper($type) . ' / ' . bunsirube_substr($label, 0, 80);
    $clicks[$key] = isset($clicks[$key]) ? (int) $clicks[$key] + 1 : 1;
    arsort($clicks);
    update_option('bunsirube_clicks', array_slice($clicks, 0, 50, true), false);

    return new WP_REST_Response(array('ok' => true), 200);
}
