<?php
/**
 * Bunsirube theme bootstrap.
 *
 * @package Bunsirube
 */

if (!defined('ABSPATH')) {
    exit;
}

define('BUNSIRUBE_VERSION', '0.3.1');
define('BUNSIRUBE_DIR', get_template_directory());
define('BUNSIRUBE_URI', get_template_directory_uri());

$bunsirube_includes = array(
    'inc/helpers.php',
    'inc/htaccess-editor.php',
    'inc/settings.php',
    'inc/json-ld.php',
    'inc/analytics.php',
    'inc/llms.php',
    'inc/cache.php',
    'inc/blocks.php',
    'inc/content-assistant.php',
    'inc/updater.php',
);

foreach ($bunsirube_includes as $bunsirube_file) {
    require_once BUNSIRUBE_DIR . '/' . $bunsirube_file;
}

add_action('after_setup_theme', 'bunsirube_setup');
function bunsirube_setup() {
    load_theme_textdomain('bunsirube', BUNSIRUBE_DIR . '/languages');

    add_theme_support('title-tag');
    add_theme_support('automatic-feed-links');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 96,
        'width'       => 96,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('wp-block-styles');
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    add_theme_support('editor-styles');
    add_theme_support('custom-header', array(
        'default-image' => '',
        'width'         => 1600,
        'height'        => 520,
        'flex-width'    => true,
        'flex-height'   => true,
    ));
    add_theme_support('custom-background', array(
        'default-color' => 'f7faf8',
    ));
    add_editor_style('assets/css/editor.css');

    register_nav_menus(array(
        'primary' => __('メインメニュー', 'bunsirube'),
    ));
}

add_action('widgets_init', 'bunsirube_widgets_init');
function bunsirube_widgets_init() {
    register_sidebar(array(
        'name'          => __('サイドバー', 'bunsirube'),
        'id'            => 'sidebar-1',
        'description'   => __('記事横に表示するウィジェットエリアです。', 'bunsirube'),
        'before_widget' => '<section id="%1$s" class="bunsirube-widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2>',
        'after_title'   => '</h2>',
    ));
}

add_action('init', 'bunsirube_register_block_styles');
function bunsirube_register_block_styles() {
    register_block_style('core/quote', array(
        'name'  => 'bunsirube-citation',
        'label' => __('文標 引用', 'bunsirube'),
    ));

    register_block_style('core/list', array(
        'name'  => 'bunsirube-checklist',
        'label' => __('文標 チェックリスト', 'bunsirube'),
    ));
}

add_action('wp_enqueue_scripts', 'bunsirube_assets');
function bunsirube_assets() {
    wp_enqueue_style('bunsirube-style', get_template_directory_uri() . '/style.css', array(), BUNSIRUBE_VERSION);
    wp_enqueue_script('bunsirube-main', BUNSIRUBE_URI . '/assets/js/main.js', array(), BUNSIRUBE_VERSION, true);
    wp_localize_script('bunsirube-main', 'bunsirubeAnalytics', array(
        'enabled'  => bunsirube_get_option('internal_analytics', '0') === '1' && is_singular() && !is_user_logged_in(),
        'endpoint' => esc_url_raw(rest_url('bunsirube/v1/click')),
        'postId'   => is_singular() ? get_queried_object_id() : 0,
    ));

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }

    $options = bunsirube_get_options();
    $main = bunsirube_normalize_hex_color($options['main_color'] ?? '#0d8f72', '#0d8f72');
    $text = bunsirube_normalize_hex_color($options['text_color'] ?? '#0b1220', '#0b1220');
    $main_dark = bunsirube_adjust_color($main, 0.78);
    $main_soft = bunsirube_mix_color($main, '#ffffff', 0.86);

    $inline = sprintf(
        ':root{--bunsirube-green:%1$s;--bunsirube-green-dark:%2$s;--bunsirube-green-soft:%3$s;--bunsirube-text:%4$s;}',
        esc_html($main),
        esc_html($main_dark),
        esc_html($main_soft),
        esc_html($text)
    );
    wp_add_inline_style('bunsirube-style', $inline);
}

add_filter('body_class', 'bunsirube_body_classes');
function bunsirube_body_classes($classes) {
    $preset = bunsirube_get_option('color_preset', 'green');
    $classes[] = 'bunsirube-preset-' . sanitize_html_class($preset);
    return $classes;
}

add_filter('wp_get_attachment_image_attributes', 'bunsirube_image_attributes');
function bunsirube_image_attributes($attr) {
    if (empty($attr['loading'])) {
        $attr['loading'] = 'lazy';
    }
    if (empty($attr['decoding'])) {
        $attr['decoding'] = 'async';
    }
    if (!empty($attr['class']) && false === strpos($attr['class'], 'bunsirube-responsive-image')) {
        $attr['class'] .= ' bunsirube-responsive-image';
    }
    return $attr;
}

add_action('wp_head', 'bunsirube_head_meta', 4);
function bunsirube_head_meta() {
    // Google Search Console 認証
    $gsc = bunsirube_get_option('gsc_verification', '');
    if ($gsc) {
        echo '<meta name="google-site-verification" content="' . esc_attr($gsc) . '">' . "\n";
    }

    $output_meta = bunsirube_get_option('output_meta_tags', '1') === '1';
    $output_ogp = bunsirube_get_option('output_ogp', '1') === '1';

    if (is_singular()) {
        global $post;
        $title   = get_the_title($post);
        $url     = get_permalink($post);
        $excerpt = bunsirube_excerpt($post, 160);

        if ($output_meta && $excerpt) {
            echo '<meta name="description" content="' . esc_attr($excerpt) . '">' . "\n";
        }

        if ($output_ogp) {
            echo '<meta property="og:type" content="article">' . "\n";
            echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
            echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
            echo '<meta property="og:locale" content="ja_JP">' . "\n";
            if ($excerpt) {
                echo '<meta property="og:description" content="' . esc_attr($excerpt) . '">' . "\n";
            }

            $img_url = '';
            if (has_post_thumbnail($post)) {
                $img_url = (string) get_the_post_thumbnail_url($post, 'large');
            }
            if (!$img_url) {
                $img_url = (string) get_site_icon_url(512);
            }
            if ($img_url) {
                echo '<meta property="og:image" content="' . esc_url($img_url) . '">' . "\n";
            }

            $card = $img_url ? 'summary_large_image' : 'summary';
            echo '<meta name="twitter:card" content="' . esc_attr($card) . '">' . "\n";
            echo '<meta name="twitter:title" content="' . esc_attr($title) . '">' . "\n";
            if ($excerpt) {
                echo '<meta name="twitter:description" content="' . esc_attr($excerpt) . '">' . "\n";
            }
            if ($img_url) {
                echo '<meta name="twitter:image" content="' . esc_url($img_url) . '">' . "\n";
            }
        }

    } elseif (is_front_page() || is_home()) {
        $name = get_bloginfo('name');
        $desc = get_bloginfo('description');
        $url  = home_url('/');
        if ($output_meta && $desc) {
            echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
        }
        if ($output_ogp) {
            echo '<meta property="og:type" content="website">' . "\n";
            echo '<meta property="og:title" content="' . esc_attr($name) . '">' . "\n";
            echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
            echo '<meta property="og:locale" content="ja_JP">' . "\n";
            if ($desc) {
                echo '<meta property="og:description" content="' . esc_attr($desc) . '">' . "\n";
            }
            $icon = (string) get_site_icon_url(512);
            if ($icon) {
                echo '<meta property="og:image" content="' . esc_url($icon) . '">' . "\n";
            }
            echo '<meta name="twitter:card" content="summary">' . "\n";
        }
    }
}

add_action('wp_head', 'bunsirube_ga4_tag', 20);
function bunsirube_ga4_tag() {
    $ga4 = bunsirube_get_option('ga4_id', '');
    if (!$ga4) {
        return;
    }
    ?>
    <script>
      window.dataLayer = window.dataLayer || [];
      window.gtag = window.gtag || function(){window.dataLayer.push(arguments);};
      window.gtag('js', new Date());
      window.gtag('config', '<?php echo esc_js($ga4); ?>');
      (window.requestIdleCallback || function(cb){window.setTimeout(cb, 1200);})(function(){
        var script = document.createElement('script');
        script.async = true;
        script.src = 'https://www.googletagmanager.com/gtag/js?id=<?php echo esc_js(rawurlencode($ga4)); ?>';
        document.head.appendChild(script);
      });
    </script>
    <?php
}
