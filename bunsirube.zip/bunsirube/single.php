<?php
/**
 * Single post template.
 *
 * @package Bunsirube
 */

get_header();
?>
<main id="content">
  <div class="bunsirube-wrap"><?php bunsirube_breadcrumb_html(); ?></div>
  <div class="bunsirube-wrap bunsirube-main">
    <div class="bunsirube-content">
      <?php while (have_posts()) : the_post(); ?>
        <article <?php post_class('bunsirube-article'); ?>>
          <div class="bunsirube-meta">
            <span><?php echo esc_html(get_the_date()); ?></span>
            <span>更新: <?php echo esc_html(get_the_modified_date()); ?></span>
            <span><?php the_author_posts_link(); ?></span>
          </div>
          <h1 class="bunsirube-post-title"><?php the_title(); ?></h1>
          <?php if (has_post_thumbnail()) : ?>
            <figure><?php the_post_thumbnail('large'); ?></figure>
          <?php endif; ?>
          <div class="bunsirube-entry">
            <?php
            the_content();
            wp_link_pages(array(
                'before' => '<nav class="bunsirube-page-links" aria-label="' . esc_attr__('Post pages', 'bunsirube') . '">',
                'after'  => '</nav>',
            ));
            ?>
          </div>
          <?php the_tags('<div class="bunsirube-tags"><span>' . esc_html__('Tags:', 'bunsirube') . '</span> ', ' ', '</div>'); ?>
          <?php echo do_shortcode('[bunsirube_author]'); ?>
          <?php comments_template(); ?>
        </article>
      <?php endwhile; ?>
    </div>
    <?php get_sidebar(); ?>
  </div>
</main>
<?php get_footer(); ?>
