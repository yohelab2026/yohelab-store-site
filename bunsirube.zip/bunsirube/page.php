<?php
/**
 * Page template.
 *
 * @package Bunsirube
 */

get_header();
?>
<main id="content">
  <div class="bunsirube-wrap"><?php bunsirube_breadcrumb_html(); ?></div>
  <div class="bunsirube-wrap bunsirube-main">
    <div class="bunsirube-content">
      <?php while (have_posts()) : the_post(); ?>
        <article <?php post_class('bunsirube-article'); ?>>
          <h1 class="bunsirube-post-title"><?php the_title(); ?></h1>
          <div class="bunsirube-entry">
            <?php
            the_content();
            wp_link_pages(array(
                'before' => '<nav class="bunsirube-page-links" aria-label="' . esc_attr__('Page links', 'bunsirube') . '">',
                'after'  => '</nav>',
            ));
            ?>
          </div>
          <?php comments_template(); ?>
        </article>
      <?php endwhile; ?>
    </div>
    <?php get_sidebar(); ?>
  </div>
</main>
<?php get_footer(); ?>
