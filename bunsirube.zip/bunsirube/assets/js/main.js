(function () {
  document.documentElement.classList.add("bunsirube-js");

  // TOC smooth scroll (iOS Safari も含めてフォールバック対応)
  document.addEventListener("click", function (e) {
    var link = e.target.closest(".bunsirube-toc a[href^='#']");
    if (!link) return;
    var id = link.getAttribute("href").slice(1);
    var target = document.getElementById(id);
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView({ behavior: "smooth", block: "start" });
    // フォーカスをターゲット見出しに移動（アクセシビリティ）
    target.setAttribute("tabindex", "-1");
    target.focus({ preventScroll: true });
  });

  document.addEventListener("click", function (e) {
    var target = e.target.closest(".bunsirube-track-click[href]");
    if (!target || !window.bunsirubeAnalytics || !window.bunsirubeAnalytics.enabled) return;

    var payload = {
      post_id: window.bunsirubeAnalytics.postId,
      type: target.getAttribute("data-bunsirube-click-type") || "cta",
      label: target.getAttribute("data-bunsirube-click-label") || target.textContent.trim().slice(0, 80),
    };

    try {
      if (navigator.sendBeacon) {
        var blob = new Blob([JSON.stringify(payload)], { type: "application/json" });
        navigator.sendBeacon(window.bunsirubeAnalytics.endpoint, blob);
        return;
      }
      fetch(window.bunsirubeAnalytics.endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        keepalive: true,
      });
    } catch (err) {
      // 計測に失敗してもリンク遷移は止めない。
    }
  });
})();
