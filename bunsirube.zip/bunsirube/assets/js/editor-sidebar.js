(function (wp) {
  if (!wp || !wp.plugins || !wp.editPost || !wp.element || !wp.components || !wp.data) {
    return;
  }

  const el = wp.element.createElement;
  const PluginDocumentSettingPanel = wp.editPost.PluginDocumentSettingPanel;
  const TextareaControl = wp.components.TextareaControl;
  const CheckboxControl = wp.components.CheckboxControl;
  const SelectControl = wp.components.SelectControl;
  const Button = wp.components.Button;
  const Notice = wp.components.Notice;
  const useSelect = wp.data.useSelect;
  const useDispatch = wp.data.useDispatch;
  const registerPlugin = wp.plugins.registerPlugin;

  const articleTypes = [
    ["basic", "基本記事"],
    ["compare", "比較記事"],
    ["review", "レビュー記事"],
    ["faq", "FAQ記事"],
    ["ranking", "ランキング記事"],
    ["product", "商品紹介記事"],
    ["case", "案件紹介記事"],
  ];

  const templates = {
    basic: [
      [2, "結論"],
      [2, "理由"],
      [2, "注意点"],
      [2, "よくある質問"],
      [2, "まとめ"],
    ],
    compare: [
      [2, "比較の結論"],
      [2, "比較表"],
      [2, "選び方"],
      [2, "注意点"],
      [2, "よくある質問"],
    ],
    review: [
      [2, "レビューの結論"],
      [2, "使って分かったこと"],
      [2, "良かった点"],
      [2, "気になった点"],
      [2, "向いている人"],
    ],
    faq: [
      [2, "先に答え"],
      [2, "よくある質問"],
      [3, "質問1"],
      [3, "質問2"],
      [3, "質問3"],
      [2, "注意点"],
    ],
    ranking: [
      [2, "ランキングの基準"],
      [2, "おすすめランキング"],
      [2, "1位"],
      [2, "2位"],
      [2, "3位"],
      [2, "選ぶときの注意点"],
    ],
    product: [
      [2, "商品の結論"],
      [2, "特徴"],
      [2, "向いている人"],
      [2, "購入前の注意点"],
      [2, "よくある質問"],
    ],
    case: [
      [2, "案件の概要"],
      [2, "向いている人"],
      [2, "応募前の注意点"],
      [2, "よくある質問"],
      [2, "次の行動"],
    ],
  };

  const typeHints = {
    basic: "結論、理由、注意点、FAQの順で書く。",
    compare: "先におすすめを出し、比較表と選び方を書く。",
    review: "使った感想、良い点、注意点、向いている人を書く。",
    faq: "質問ごとに短く答え、最後に注意点をまとめる。",
    ranking: "順位の理由と、選び方の基準を先に書く。",
    product: "誰向けの商品か、特徴、購入前の注意点を書く。",
    case: "内容、向いている人、応募前の注意点を書く。",
  };

  const fields = [
    ["intent", "この記事で答えること"],
    ["conclusion", "先に出す答え"],
    ["evidence", "理由・比較・参考リンク"],
    ["caution", "注意点・補足"],
    ["cta", "最後に促す行動"],
  ];

  const checks = [
    ["title", "タイトルが具体的"],
    ["conclusion", "最初に答えを書いた"],
    ["ai_answer", "AI検索にも読まれやすい短い答えを置いた"],
    ["evidence", "理由・比較を書いた"],
    ["caution", "注意点を書いた"],
    ["faq", "FAQを入れた"],
    ["source", "出典・参考リンクを書いた"],
    ["compare", "必要なら比較表を入れた"],
    ["summary", "最後にまとめた"],
    ["cta", "最後の行動が分かる"],
    ["mobile", "スマホで長すぎないか見た"],
    ["updated", "情報が古くないか見た"],
  ];

  const placeholders = {
    intent: "例：どれを選べばいいか",
    conclusion: "例：初心者は軽くて設定が少ないものがいい",
    evidence: "例：表示速度、設定項目、プラグイン数を比較",
    caution: "例：順位や売上は保証できない",
    cta: "例：無料体験、購入ページ、問い合わせへ進む",
  };

  function metaKey(field) {
    return "_aio_assistant_" + field;
  }

  function checkKey(field) {
    return "_aio_assistant_check_" + field;
  }

  function SidebarPanel() {
    const meta = useSelect(function (select) {
      return select("core/editor").getEditedPostAttribute("meta") || {};
    }, []);
    const content = useSelect(function (select) {
      return select("core/editor").getEditedPostContent() || "";
    }, []);
    const editPost = useDispatch("core/editor").editPost;
    const editBlocks = useDispatch("core/block-editor");
    const score = checks.filter(function (item) {
      return meta[checkKey(item[0])] === "1";
    }).length;
    const selectedType = meta[metaKey("type")] || "basic";
    const sampleTexts = [
      "https://example.com",
      "http://example.com",
      "価格を入力",
      "特徴を入力",
      "向いている人を入力",
      "注意点を入力",
      "ここに、読者に進んでほしい行動を短く書きます",
      "Aサービス",
      "Bサービス",
    ];
    const hasSampleText = sampleTexts.some(function (sample) {
      return content.indexOf(sample) !== -1;
    });
    const clickStats = [
      ["CTAクリック", meta["_bunsirube_clicks_cta"] || 0],
      ["比較表クリック", meta["_bunsirube_clicks_compare"] || 0],
      ["広告リンククリック", meta["_bunsirube_clicks_ad"] || 0],
      ["ブログカードクリック", meta["_bunsirube_clicks_blogcard"] || 0],
    ];

    function updateMeta(key, value) {
      const next = {};
      next[key] = value;
      editPost({ meta: next });
    }

    function insertCtaBlock() {
      if (editBlocks && editBlocks.insertBlocks && wp.blocks && wp.blocks.createBlock) {
        editBlocks.insertBlocks(
          wp.blocks.createBlock("core/shortcode", {
            text: '[bunsirube_cta title="次にすること" text="ここに、読者に進んでほしい行動を短く書きます。" button="詳しく見る" url="https://example.com"]',
          })
        );
      }
    }

    function insertCompareBlock() {
      if (editBlocks && editBlocks.insertBlocks && wp.blocks && wp.blocks.createBlock) {
        editBlocks.insertBlocks(
          wp.blocks.createBlock("core/shortcode", {
            text: '[bunsirube_compare_grid][bunsirube_compare_item name="Aサービス" price="価格を入力" feature="特徴を入力" fit="向いている人を入力" caution="注意点を入力" label="おすすめ" button="詳しく見る" url="https://example.com"][bunsirube_compare_item name="Bサービス" price="価格を入力" feature="特徴を入力" fit="向いている人を入力" caution="注意点を入力" button="詳しく見る" url="https://example.com"][/bunsirube_compare_grid]',
          })
        );
      }
    }

    function insertBlogCardBlock() {
      if (editBlocks && editBlocks.insertBlocks && wp.blocks && wp.blocks.createBlock) {
        editBlocks.insertBlocks(
          wp.blocks.createBlock("core/shortcode", {
            text: '[bunsirube_blog_card url="https://example.com"]',
          })
        );
      }
    }

    return el(
      PluginDocumentSettingPanel,
      {
        name: "bunsirube-content-assistant",
        title: "記事設計",
        className: "bunsirube-content-assistant",
        initialOpen: true,
      },
      el(
        Notice,
        { status: "success", isDismissible: false },
        "記事完成チェック " + score + "/" + checks.length
      ),
      hasSampleText
        ? el(
            Notice,
            { status: "warning", isDismissible: false },
            "サンプルURLや仮文言が残っています。公開前に自分の内容へ変更してください。"
          )
        : null,
      el(
        "div",
        {
          style: {
            margin: "10px 0",
            padding: "10px",
            background: "#f6f7f7",
            borderRadius: "8px",
            color: "#50575e",
          },
        },
        el("strong", null, "この記事の導線確認"),
        clickStats.map(function (item) {
          return el(
            "p",
            { key: item[0], style: { margin: "6px 0 0" } },
            item[0] + ": " + item[1]
          );
        }),
        el("p", { style: { margin: "8px 0 0", fontSize: "12px" } }, "内部アクセス解析ON時の参考値です。ONにすると、この記事のCTA・比較表・広告リンク・ブログカードクリックが表示されます。")
      ),
      el(
        "p",
        { style: { marginTop: "8px", color: "#646970" } },
        "記事タイプを選んで、答え・理由・注意点だけ先に決めます。AI検索向けの特別な裏技ではなく、短い答え・根拠・FAQ・出典が本文に見える状態を目指します。"
      ),
      el(SelectControl, {
        label: "記事タイプ",
        value: meta[metaKey("type")] || "basic",
        options: articleTypes.map(function (item) {
          return { value: item[0], label: item[1] };
        }),
        onChange: function (value) {
          updateMeta(metaKey("type"), value);
        },
      }),
      el(
        "p",
        {
          style: {
            marginTop: "-6px",
            padding: "8px 10px",
            background: "#f6f7f7",
            borderRadius: "8px",
            color: "#50575e",
          },
        },
        typeHints[selectedType]
      ),
      el(Button, {
        variant: "secondary",
        style: { width: "100%", justifyContent: "center", marginBottom: "8px" },
        onClick: function () {
          if (editBlocks && editBlocks.insertBlocks && wp.blocks && wp.blocks.createBlock) {
            editBlocks.insertBlocks(
              templates[selectedType].map(function (heading) {
                return wp.blocks.createBlock("core/heading", {
                  content: heading[1],
                  level: heading[0],
                });
              })
            );
          }
        },
      }, "この型の見出しを入れる"
      ),
      el(Button, {
        variant: "secondary",
        style: { width: "100%", justifyContent: "center", marginBottom: "12px" },
        onClick: insertCtaBlock,
      }, "CTAを入れる"
      ),
      el(Button, {
        variant: "secondary",
        style: { width: "100%", justifyContent: "center", marginBottom: "12px" },
        onClick: insertCompareBlock,
      }, "比較表カードを入れる"
      ),
      el(Button, {
        variant: "secondary",
        style: { width: "100%", justifyContent: "center", marginBottom: "12px" },
        onClick: insertBlogCardBlock,
      }, "ブログカードを入れる"
      ),
      el(
        "p",
        { style: { marginTop: "-4px", color: "#646970", fontSize: "12px" } },
        "見出しだけ入るので、本文はあとから自由に書けます。"
      ),
      fields.map(function (item) {
        return el(TextareaControl, {
          key: item[0],
          label: item[1],
          placeholder: placeholders[item[0]],
          value: meta[metaKey(item[0])] || "",
          rows: 2,
          onChange: function (value) {
            updateMeta(metaKey(item[0]), value);
          },
        });
      }),
      el(
        "div",
        { style: { display: "grid", gap: "8px", marginTop: "10px" } },
        checks.map(function (item) {
          return el(CheckboxControl, {
            key: item[0],
            label: item[1],
            checked: meta[checkKey(item[0])] === "1",
            onChange: function (checked) {
              updateMeta(checkKey(item[0]), checked ? "1" : "");
            },
          });
        })
      )
    );
  }

  registerPlugin("bunsirube-content-assistant", {
    render: SidebarPanel,
    icon: "welcome-write-blog",
  });
})(window.wp);
