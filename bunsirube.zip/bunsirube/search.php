<?php
/**
 * Search results template.
 *
 * @package Bunsirube
 */

get_header();
?>
<main id="content">
  <section class="bunsirube-hero">
    <div class="bunsirube-wrap">
      <div class="bunsirube-hero-card">
        <span class="bunsirube-eyebrow">Search</span>
        <h1 class="bunsirube-title"><?php printf(esc_html__('Search results for: %s', 'bunsirube'), get_search_query()); ?></h1>
        <p class="bunsirube-lead">探している記事を、できるだけすぐ見つけやすくする。</p>
      </div>
    </div>
  </section>
  <div class="bunsirube-wrap bunsirube-main">
    <div class="bunsirube-content">
      <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
          <article <?php post_class('bunsirube-article'); ?>>
            <h2 class="bunsirube-post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <div class="bunsirube-entry"><?php the_excerpt(); ?></div>
          </article>
        <?php endwhile; ?>
        <?php the_posts_pagination(); ?>
      <?php else : ?>
        <article class="bunsirube-article">
          <h2 class="bunsirube-post-title">該当する記事がありません</h2>
          <p>別のキーワードで検索してみてください。</p>
        </article>
      <?php endif; ?>
    </div>
    <?php get_sidebar(); ?>
  </div>
</main>
<?php get_footer(); ?>
